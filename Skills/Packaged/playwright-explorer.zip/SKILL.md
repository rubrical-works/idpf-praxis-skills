---
name: playwright-explorer
description: Interactive browser exploration using Playwright with natural language interaction, DOM reading, and session management
version: "1.0.0"
frameworkCompatibility: ">=0.60.0"
lastUpdated: "2026-03-17"
license: Complete terms in LICENSE.txt
category: testing
relevantTechStack: [playwright, e2e, browser-testing, web-app, frontend]
invocationMode: direct-only
copyright: "Rubrical Works (c) 2026"
---

# Playwright Explorer

Natural language-driven DOM inspection, element interaction, and session management against running web applications via Playwright.

## When to Use This Skill

- Exploring a running web application interactively
- Inspecting DOM structure, visible text, or interactive elements
- Performing natural language browser interactions (click, fill, navigate)
- Debugging UI issues or verifying UI state during development

## Prerequisites

- Node.js 18+, a running web application (dev server)
- Playwright and Chromium (auto-installed if missing)

## Modules

| Module | Purpose |
|--------|---------|
| `preflight.js` | Detects and installs required components |
| `detect-components.js` | Detects Node.js, Playwright, Chromium, system deps |
| `auto-install.js` | Installs missing components (packages require user confirmation) |
| `browser-connection.js` | URL-based and CDP-based connection with dev server auto-detection |
| `dom-reader.js` | Extracts visible text, interactive elements, layout, styles, test IDs |
| `nl-interaction.js` | Natural language action execution with priority-based selector resolution |
| `session-lifecycle.js` | Background process persistence, file-based IPC, health checks, cleanup |
| `error-recovery.js` | Crash handling, timeout recovery, orphaned process cleanup |

## Workflow

### 1. Pre-Flight Check
`preflight.verifyAll()` detects Node.js 18+, `@playwright/test`, Chromium binary, system deps (Linux). Missing components auto-installed (packages require user confirmation).

### 2. Connect
`browser-connection.connect()` with target URL or auto-detect ports (3000, 5173, 8080, 4200, 8000, 4000, 3001).

### 3. Explore
- **Read DOM** — `extractVisibleText()`, `extractInteractiveElements()`, `extractTestIds()`
- **Interact** — `executeAction()` supports click, fill, type, goto, goBack, waitForSelector
- **Selector priority** — data-testid > ARIA role > visible text > CSS

### 4. Session Management
Sessions persist via file-based IPC (`.tmp-pw-cmd.json`, `.tmp-pw-result.json`). Health checks detect stale sessions. Error recovery handles crashes, timeouts, connection loss.

## Error Handling

All modules return `{ success, error }`. Handles target app crashes, action timeouts (30s navigation, 10s element), orphaned browser processes/temp files, connection loss with reconnection guidance.

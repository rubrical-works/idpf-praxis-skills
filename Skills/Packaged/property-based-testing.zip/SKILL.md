---
name: property-based-testing
description: Guide developers through property-based testing including property definition, shrinking, and framework-specific implementation
version: "1.0.0"
frameworkCompatibility: ">=0.60.0"
lastUpdated: "2026-03-17"
license: Complete terms in LICENSE.txt
category: testing
relevantTechStack: [fast-check, hypothesis, property-testing, javascript, python]
invocationMode: direct-only
copyright: "Rubrical Works (c) 2026"
---

# Property-Based Testing

## When to Use This Skill

- Writing tests for functions with many possible inputs
- Testing mathematical or algorithmic properties
- Finding edge cases traditional testing might miss
- Verifying serialization/deserialization roundtrips
- Testing parsers or data transformations

## What is Property-Based Testing?

**Traditional (example-based):** Tests specific input/output pairs.
**Property-based:** Defines invariants that hold for all valid inputs; framework generates test cases automatically.

**Key Concepts:**
- **Property:** An assertion that should hold for all valid inputs
- **Generator:** Creates random test inputs
- **Shrinking:** When a test fails, finds the minimal failing case
- **Counterexample:** A specific input that violates the property

## Property Definition Patterns

### Common Property Types

**Roundtrip/Inverse:**
```
For all x: decode(encode(x)) == x
For all x: uncompress(compress(x)) == x
```

**Idempotence:**
```
For all x: f(f(x)) == f(x)
For all x: sort(sort(list)) == sort(list)
```

**Commutativity:**
```
For all a, b: add(a, b) == add(b, a)
```

**Associativity:**
```
For all a, b, c: f(f(a, b), c) == f(a, f(b, c))
```

**Identity:**
```
For all x: add(x, 0) == x
For all list: concat(list, []) == list
```

**Invariant:**
```
For all inserts: len(list) increases by 1
For all valid inputs: output is within expected range
```

**Comparison to Reference:**
```
For all x: optimized(x) == naive(x)
```

### Writing Good Properties

- Describe what, not how: "sorting preserves length" not "first pass puts smallest element first"
- Make properties specific: `For all lists, len(reverse(list)) == len(list)`
- Combine multiple properties for thorough coverage

## Generators

Most frameworks provide built-in generators for: integers, floats, strings, booleans, lists/arrays, dictionaries/maps, optional/nullable values.

**Constrained values:**
```
positive_int = integers(min_value=1)
small_list = lists(integers(), min_size=0, max_size=10)
```

**Composite generators:**
```
user = builds(User,
    name=text(min_size=1, max_size=50),
    age=integers(min_value=0, max_value=150),
    email=emails())
```

**Generator best practices:**
1. Start simple — use built-in generators first
2. Add constraints gradually — only constrain what's necessary
3. Cover edge cases — include boundaries and special values
4. Match domain — generate realistic data for your domain

## Shrinking

When a test fails, the framework generates simpler versions of the failing input until no simpler failing input is found. The minimal failing case reveals the bug.

**Shrinking strategies:** For integers: try 0, then values closer to 0. For strings: try empty, then shorter. For lists: try empty, then smaller, then simpler elements.

**When you get a minimal failing case:**
1. Understand why it fails
2. Add as regression test
3. Fix the bug
4. Re-run property test to confirm

## Integration with Test Suites

- Start with example tests for known important cases
- Add property tests for additional coverage
- Keep both — they serve different purposes

**Use example tests for:** Known edge cases, bug reproductions, documentation of expected behavior, fast deterministic checks.
**Use property tests for:** General invariants, random edge case discovery, mathematical properties, serialization roundtrips.

## Framework-Specific Guidance

### Python (Hypothesis)

```python
from hypothesis import given, strategies as st

@given(st.lists(st.integers()))
def test_sort_preserves_length(lst):
    assert len(sorted(lst)) == len(lst)

@given(st.integers(), st.integers())
def test_addition_commutative(a, b):
    assert a + b == b + a
```

### JavaScript (fast-check)

```javascript
const fc = require('fast-check');

test('sort preserves length', () => {
  fc.assert(
    fc.property(fc.array(fc.integer()), (arr) => {
      return arr.sort().length === arr.length;
    })
  );
});
```

### Haskell (QuickCheck)

```haskell
prop_sort_preserves_length :: [Int] -> Bool
prop_sort_preserves_length xs = length (sort xs) == length xs
```

### Other Frameworks

| Language | Framework | Notes |
|----------|-----------|-------|
| Python | Hypothesis | Most popular, excellent shrinking |
| JavaScript | fast-check | Good performance, TypeScript support |
| Java | jqwik | JUnit 5 integration |
| Scala | ScalaCheck | Inspired by QuickCheck |
| Rust | proptest | Good Rust integration |
| Go | gopter | Based on ScalaCheck |
| Erlang | PropEr | For concurrent systems |

## Common Pitfalls

1. **Overly constrained generators** — Test with varying sizes including empty
2. **Testing implementation details** — Test properties, not implementation
3. **Non-deterministic properties** — Use deterministic properties
4. **Slow generators** — Size inputs appropriately, use max_examples setting
5. **Ignoring counterexamples** — Fix the bug, add counterexample as regression test

## Debugging Failed Properties

1. Read the counterexample — understand the failing input
2. Reproduce manually — run with the exact counterexample
3. Add debug logging — trace execution with counterexample
4. Fix the bug — use insights to fix
5. Add regression test — keep counterexample as example test

## Resources

See `resources/` directory for:
- `property-patterns.md` - Additional property patterns
- `shrinking-guide.md` - Detailed shrinking explanation
- `framework-examples.md` - Framework-specific code examples

## Relationship to Other Skills

- `test-writing-patterns` - Example-based testing patterns
- `mutation-testing` - Test suite quality assessment
- `tdd-red-phase` - Writing failing tests first

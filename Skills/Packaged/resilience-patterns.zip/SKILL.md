---
name: resilience-patterns
description: Fault tolerance patterns for distributed systems — retry, circuit breaker, fallback, bulkhead, and timeout
version: "1.0.0"
frameworkCompatibility: ">=0.60.0"
lastUpdated: "2026-03-17"
license: Complete terms in LICENSE.txt
category: architecture
relevantTechStack: [distributed-systems, microservices, api, node, python, go, java, rust]
invocationMode: auto
copyright: "Rubrical Works (c) 2026"
---

# Resilience Patterns

Fault tolerance patterns for systems communicating with external services, databases, or unreliable dependencies.

## When to Use This Skill

- Implementing calls to external APIs or services
- Adding database connection resilience
- Designing microservice communication
- Handling transient failures (network timeouts, rate limits)
- Building graceful degradation into applications

## Resilience Philosophy

1. **Assume failure:** External dependencies will fail — design for it
2. **Fail fast:** Detect failure quickly rather than waiting for timeouts
3. **Degrade gracefully:** Provide reduced functionality rather than none
4. **Recover automatically:** Systems should self-heal when dependencies recover
5. **Isolate failures:** Prevent one failing dependency from cascading

## Pattern 1: Retry with Exponential Backoff

Automatically retry transient failures with increasing delay.

**Use for:** Network timeouts, HTTP 429/503, database connection failures.
**Do NOT use for:** HTTP 400/401/403/404, validation errors, business logic failures.

```python
# Python
import time

def with_retry(func, max_attempts=3, backoff_factor=2, retryable=None):
    for attempt in range(max_attempts):
        try:
            return func()
        except Exception as e:
            if retryable and not retryable(e):
                raise
            if attempt >= max_attempts - 1:
                raise
            time.sleep(backoff_factor ** attempt)
```

```javascript
// JavaScript
async function withRetry(fn, { maxAttempts = 3, backoff = 2 } = {}) {
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    try {
      return await fn();
    } catch (err) {
      if (attempt >= maxAttempts - 1) throw err;
      await new Promise(r => setTimeout(r, backoff ** attempt * 1000));
    }
  }
}
```

```go
// Go
func withRetry(fn func() error, maxAttempts int) error {
    var lastErr error
    for i := 0; i < maxAttempts; i++ {
        if err := fn(); err != nil {
            lastErr = err
            time.Sleep(time.Duration(math.Pow(2, float64(i))) * time.Second)
            continue
        }
        return nil
    }
    return fmt.Errorf("failed after %d attempts: %w", maxAttempts, lastErr)
}
```

| Parameter | Default | Description |
|-----------|---------|-------------|
| Max attempts | 3 | Total tries before giving up |
| Backoff factor | 2 | Multiplier for delay between retries |
| Max delay | 30s | Cap on backoff to prevent excessive waits |
| Jitter | ±20% | Random variation to prevent thundering herd |

## Pattern 2: Circuit Breaker

Prevent cascading failures by short-circuiting calls to failing dependencies.

**States:**
```
CLOSED → (failures exceed threshold) → OPEN
OPEN → (recovery timeout expires) → HALF-OPEN
HALF-OPEN → (test call succeeds) → CLOSED
HALF-OPEN → (test call fails) → OPEN
```

```python
# Python
import time

class CircuitBreaker:
    def __init__(self, failure_threshold=5, recovery_timeout=60):
        self.failure_count = 0
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.state = 'closed'
        self.last_failure_time = None

    def call(self, func):
        if self.state == 'open':
            if time.time() - self.last_failure_time > self.recovery_timeout:
                self.state = 'half-open'
            else:
                raise CircuitOpenError('Circuit breaker is open')
        try:
            result = func()
            if self.state == 'half-open':
                self.state = 'closed'
                self.failure_count = 0
            return result
        except Exception:
            self.failure_count += 1
            self.last_failure_time = time.time()
            if self.failure_count >= self.failure_threshold:
                self.state = 'open'
            raise
```

| Parameter | Default | Description |
|-----------|---------|-------------|
| Failure threshold | 5 | Failures before opening circuit |
| Recovery timeout | 60s | Time before attempting half-open |
| Success threshold | 1 | Successes in half-open before closing |

## Pattern 3: Fallback

Provide alternative responses when primary source fails.

```python
# Python
def get_user_with_fallback(user_id):
    try:
        return user_service.get_user(user_id)
    except ExternalServiceError:
        cached = cache.get(f'user:{user_id}')
        if cached:
            return cached
        return User.default(user_id)
```

| Strategy | Use When | Trade-off |
|----------|----------|-----------|
| Cache fallback | Stale data is acceptable | Data may be outdated |
| Default value | Safe default exists | Reduced functionality |
| Alternative service | Backup service available | Additional infrastructure |
| Graceful degradation | Feature can be disabled | Missing functionality |

## Pattern 4: Bulkhead

Isolate failure domains so one failing dependency doesn't exhaust all resources.

```javascript
// JavaScript — Semaphore-based bulkhead
class Bulkhead {
  constructor(maxConcurrent) {
    this.maxConcurrent = maxConcurrent;
    this.running = 0;
    this.queue = [];
  }
  async execute(fn) {
    if (this.running >= this.maxConcurrent) {
      await new Promise(resolve => this.queue.push(resolve));
    }
    this.running++;
    try {
      return await fn();
    } finally {
      this.running--;
      if (this.queue.length > 0) this.queue.shift()();
    }
  }
}

const dbBulkhead = new Bulkhead(10);
const apiBulkhead = new Bulkhead(5);
```

## Pattern 5: Timeout

Prevent hanging operations by enforcing maximum wait times.

```python
# Python
import asyncio

async def with_timeout(coro, timeout_seconds=5):
    try:
        return await asyncio.wait_for(coro, timeout=timeout_seconds)
    except asyncio.TimeoutError:
        raise TimeoutError(f"Operation timed out after {timeout_seconds}s")
```

```go
// Go — context-based timeout
func getUserWithTimeout(ctx context.Context, id string) (*User, error) {
    ctx, cancel := context.WithTimeout(ctx, 5*time.Second)
    defer cancel()
    return db.FindUserContext(ctx, id)
}
```

| Operation | Typical Timeout | Notes |
|-----------|----------------|-------|
| Database query | 5-10s | Longer for complex reports |
| HTTP API call | 10-30s | Depends on SLA |
| Cache lookup | 100-500ms | Should be fast |
| DNS resolution | 2-5s | Usually <1s |

## Combining Patterns

```
Request → Timeout → Retry → Circuit Breaker → Bulkhead → Service Call
```

- **Retry + Circuit Breaker:** Retry transient failures, but stop when service is truly down
- **Timeout + Retry:** Don't retry if already timed out
- **Bulkhead + Circuit Breaker:** Isolate per dependency, break circuit per dependency
- **Fallback + Circuit Breaker:** When circuit opens, use fallback immediately

## Resources

- `resources/pattern-selection-guide.md` — Decision tree for choosing patterns
- `resources/combined-patterns.md` — Multi-pattern implementation examples

## Relationship to Other Skills

- `error-handling-patterns` — Error hierarchy that resilience patterns use
- `anti-pattern-analysis` — Detects missing resilience patterns

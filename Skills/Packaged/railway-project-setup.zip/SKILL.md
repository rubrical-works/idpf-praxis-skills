---
name: railway-project-setup
description: Configure automated preview, staging, and production deployments with Railway
version: "1.0.0"
frameworkCompatibility: ">=0.60.0"
lastUpdated: "2026-03-17"
license: Complete terms in LICENSE.txt
category: platform
relevantTechStack: [railway, docker, node, python, deployment]
invocationMode: direct-only
copyright: "Rubrical Works (c) 2026"
---

# Skill: railway-project-setup

**Purpose:** Guide developers through setting up Railway deployments with GitHub Actions integration
**Audience:** Developers deploying web applications and services to Railway
**Related Skills:** `ci-cd-pipeline-design` — for broader CI/CD pipeline architecture

## Overview

Provides structured guidance for configuring Railway deployments across preview (PR environments), staging, and production environments. Railway excels at deploying full-stack applications with databases, background workers, and cron jobs in a unified platform.

## Initial Setup

### Prerequisites

- Railway account (free tier or Pro plan for team features)
- Railway CLI installed: `npm install -g @railway/cli`
- GitHub repository with push access

### Linking Your Project

```bash
railway login
railway link      # Link to an existing project
railway init      # Or initialize a new project
```

### Project Structure

- **Project**: Top-level container (e.g., "my-app")
- **Service**: Individual deployable unit (e.g., "web", "api", "worker")
- **Environment**: Deployment target (e.g., "production", "staging", "pr-123")

## Environment Configuration

### Required Secrets

Configure in GitHub repository settings (Settings > Secrets and variables > Actions):

| Secret | Source | Description |
|--------|--------|-------------|
| `RAILWAY_TOKEN` | Railway Dashboard > Account > Tokens | API authentication token |

Railway auto-injects `PORT`, `RAILWAY_ENVIRONMENT`, and `RAILWAY_SERVICE_NAME` per service. Set per-service variables in Railway Dashboard (Service > Variables tab).

See `resources/env-setup.md` for a complete guide.

## GitHub Integration

### Native GitHub Integration

1. Connect GitHub repo in Railway Dashboard (Project > Settings > Source)
2. Select branch for production deploys
3. Enable PR environments for preview deployments

### GitHub Actions Deployment

```yaml
# See resources/deploy.yml for complete workflow
- name: Deploy to Railway
  run: railway up --service ${{ vars.RAILWAY_SERVICE }}
  env:
    RAILWAY_TOKEN: ${{ secrets.RAILWAY_TOKEN }}
```

## PR Environments (Preview Deployments)

Creates isolated copies of your services for each pull request.

**Enabling:** Project > Settings > Environments > Enable "PR Environments"

Each PR gets a full environment with its own service instances, database instances (cloned from staging/production), and environment variables. PR environments are automatically destroyed when the PR is closed or merged.

**Limitations:**
- PR environments share the project's resource limits
- Database cloning may increase costs on large datasets
- Some external services may need manual configuration per PR

## Deployment Strategies

```
main branch → Production environment (automatic)
```

**Staging:** Create dedicated environment in Railway Dashboard > Project > Environments > New Environment, name it "staging", configure branch trigger.

```bash
railway up --service web                        # Deploy current directory
railway up --service web --environment staging  # Deploy to specific environment
railway rollback                                # Rollback to previous deployment
```

## Monitoring and Debugging

```bash
railway logs --service web
railway logs --deployment-id <id>
```

Health check configuration in `railway.toml`:

```toml
[deploy]
healthcheckPath = "/api/health"
healthcheckTimeout = 30
```

## Common Pitfalls and Troubleshooting

**Build Issues:**
- **Nixpacks detection failure**: Ensure standard config files (`package.json`, `requirements.txt`) or specify custom Dockerfile
- **Build timeout**: Optimize with `.railwayignore` to exclude unnecessary files
- **Missing dependencies**: Ensure all system dependencies are declared

**Deployment Issues:**
- **Port binding**: Listen on `process.env.PORT` or `0.0.0.0:$PORT`
- **Database connection drops**: Use connection pooling and configure `PGBOUNCER_URL` for PostgreSQL
- **Cold starts**: Railway keeps services running on Pro plan; free tier may sleep after inactivity

**CI/CD Issues:**
- **Token scoping**: Ensure `RAILWAY_TOKEN` has access to the target project
- **Service targeting**: Always specify `--service` when deploying to multi-service projects
- **Environment isolation**: PR environment variables default to staging values unless overridden

## Resources

- `resources/railway.toml` — Reference Railway configuration
- `resources/deploy.yml` — GitHub Actions workflow for Railway deployment
- `resources/env-setup.md` — Environment variable setup guide

## Related Skills

- **`ci-cd-pipeline-design`** — Architecture patterns for CI/CD pipelines, stage design, and security considerations

---
name: beginner-testing
description: Introduce test-driven development to beginners with simple Flask/Sinatra test examples and TDD concepts
version: "1.0.0"
frameworkCompatibility: ">=0.60.0"
lastUpdated: "2026-03-17"
license: Complete terms in LICENSE.txt
category: testing
relevantTechStack: [flask, sinatra, python, ruby, tdd]
invocationMode: auto
copyright: "Rubrical Works (c) 2026"
---

# Beginner Testing Introduction

This Skill introduces beginners to automated testing and Test-Driven Development (TDD) with simple, understandable examples.

## When to Use This Skill

- User has working Vibe app ready to transition to Structured Phase
- User mentions "testing" or asks about "how to test"
- Evolution Point reached (user says "Ready-to-Structure")
- User has built 3-4 features and wants to add quality assurance
- User asks "How do I know if my code works?"

## Prerequisites

- Working Flask or Sinatra app with 3-4 features
- Understanding of routes and functions
- Comfortable with basic programming concepts
- Code that works, but no tests yet

## What is Testing?

```
Without tests:                    With tests:
1. Make a change to code          1. Make a change to code
2. Open browser                   2. Run tests (one command)
3. Click around manually          3. See green ✓ or red ✗
4. Hope nothing broke             4. Know immediately if something broke
5. Repeat for every change        5. Fix before users see the problem!
```

## What is TDD (Test-Driven Development)?

```
RED → GREEN → REFACTOR

1. RED: Write a test that fails (feature doesn't exist yet)
2. GREEN: Write just enough code to make test pass
3. REFACTOR: Clean up the code (tests still pass)
Then repeat for next feature!
```

## Types of Tests

1. **Unit Tests** - Tests individual functions (e.g., `add_numbers(2, 3)` returns `5`)
2. **Route Tests** - Tests that web pages load correctly (e.g., visiting `/` returns status 200)
3. **Integration Tests** - Tests that different parts work together

**For beginners: Start with route tests!** Easiest to understand.

## Your First Test (Flask)

```python
# test_app.py

def test_homepage_loads():
    """Test that homepage loads without errors."""
    from app import app

    # Create test client (fake browser)
    client = app.test_client()

    # Visit homepage
    response = client.get('/')

    # Check: Did it work?
    assert response.status_code == 200  # 200 = success
```

```bash
pip install pytest    # Install testing tool
pytest                # Run all tests
```

## Your First Test (Sinatra)

```ruby
# test_app.rb

require 'minitest/autorun'
require 'rack/test'
require_relative 'app'

class AppTest < Minitest::Test
  include Rack::Test::Methods

  def app
    Sinatra::Application
  end

  def test_homepage_loads
    get '/'
    assert last_response.ok?  # ok? means status 200
  end
end
```

```bash
ruby test_app.rb
```

## Common Test Assertions

**Python (pytest):**
```python
assert something == True       # Must be True
assert value == 5              # Must equal 5
assert 'text' in response.data # Must contain 'text'
assert value != 0              # Must not equal 0
```

**Ruby (minitest):**
```ruby
assert something               # Must be truthy
assert_equal 5, value          # Must equal 5
assert_includes body, 'text'   # Must contain 'text'
refute_equal 0, value          # Must not equal 0
```

## TDD Example: Adding a Feature

**Step 1: RED - Write failing test**
```python
def test_delete_note():
    client = app.test_client()
    client.post('/add', data={'note': 'Test note'})
    response = client.get('/delete/1')
    assert response.status_code == 302
```

**Step 2: GREEN - Make test pass**
```python
@app.route('/delete/<int:note_id>')
def delete_note(note_id):
    conn = get_db()
    conn.execute('DELETE FROM notes WHERE id = ?', (note_id,))
    conn.commit()
    conn.close()
    return redirect('/')
```

**Step 3: REFACTOR - Clean up** (tests still pass!)

## Test Organization

```
my-project/
├── app.py              # Your code
├── test_app.py         # Your tests
├── templates/
│   └── index.html
└── notes.db
```

**Test file naming:**
- Python: `test_*.py` or `*_test.py`
- Ruby: `*_test.rb` or `test_*.rb`

## What to Test

**For beginners, test:**
- Routes exist (not 404)
- Forms submit successfully
- Data saves to database
- Data displays correctly

**Don't worry yet about:** Edge cases, error handling, performance, security.

## Common Testing Mistakes

1. **Not running tests** — Run tests after every change
2. **Tests depend on order** — Each test should work independently
3. **Testing too much at once** — Small tests, one thing each
4. **Not testing the right thing** — Actually verify the important behavior

## Benefits of TDD for Beginners

1. **Clarity** — Test defines what "working" means before you code
2. **Confidence** — Know immediately when something breaks
3. **Better Code** — Testable code is usually better organized
4. **Documentation** — Tests show how to use your code
5. **Less Fear** — Change code without worrying about breaking things

## Complete Examples

Full working examples with explanations:
- `resources/flask-test-example.py`
- `resources/sinatra-test-example.rb`
- `resources/tdd-explained.md`

## Next Steps After First Tests

Once comfortable with basic testing:
- Add more route tests
- Test form submissions
- Test database operations
- Test error handling
- Learn fixtures (test data setup)
- Learn mocking (fake external services)

## When Tests Feel Hard

If writing a test is difficult, your code might be too complex. Break it into smaller pieces — each piece will be easier to test. This is TDD helping you write better code!

---
name: mutation-testing
description: Guide developers through mutation testing to assess and improve test suite quality
version: "1.0.0"
frameworkCompatibility: ">=0.60.0"
lastUpdated: "2026-03-17"
license: Complete terms in LICENSE.txt
category: testing
relevantTechStack: [stryker, mutation-testing, javascript, typescript]
invocationMode: direct-only
copyright: "Rubrical Works (c) 2026"
---

# Mutation Testing

This Skill guides developers through mutation testing, a technique for evaluating test suite quality by introducing small changes (mutations) to code and checking if tests catch them.

## When to Use This Skill

- Assessing test suite quality beyond code coverage
- Identifying weak spots in test coverage
- Evaluating whether tests are meaningful
- Improving test effectiveness
- Making decisions about test maintenance

## What is Mutation Testing?

1. **Mutate:** Make small changes to source code (mutations)
2. **Test:** Run test suite against mutated code
3. **Evaluate:** Check if tests detect (kill) the mutations

### Key Terms

- **Mutant:** A modified version of the original code with one small change
- **Mutation Operator:** A rule defining how to modify code (e.g., change `+` to `-`)
- **Killed Mutant:** A mutant detected by at least one failing test
- **Survived Mutant:** A mutant not detected by any test (tests still pass)
- **Equivalent Mutant:** A mutant that behaves identically to original (cannot be killed)
- **Mutation Score:** `killed / (total - equivalent)` percentage

## Why Mutation Testing?

Code coverage alone misses weak tests:
```python
# 100% coverage but weak test
def test_discount():
    assert calculate_discount(100, True) is not None  # Doesn't check actual value!

# Mutation: change 0.9 to 0.8 → weak test still passes → mutant SURVIVES
```

## Mutation Operators

### Arithmetic Operators

| Original | Mutated |
|----------|---------|
| `+` | `-` |
| `-` | `+` |
| `*` | `/` |
| `/` | `*` |
| `%` | `*` |

### Relational Operators

| Original | Mutated |
|----------|---------|
| `<` | `<=` |
| `<=` | `<` |
| `>` | `>=` |
| `>=` | `>` |
| `==` | `!=` |
| `!=` | `==` |

### Logical Operators

| Original | Mutated |
|----------|---------|
| `and` | `or` |
| `or` | `and` |
| `not` | (removed) |

### Constant Mutations

| Original | Mutated |
|----------|---------|
| `0` | `1` |
| `1` | `0` |
| `true` | `false` |
| `""` | `"mutant"` |

### Statement Mutations

| Type | Description |
|------|-------------|
| Statement deletion | Remove a statement |
| Return value | Change return (`return x` → `return 0`) |
| Void call removal | Remove void method call |

## Understanding Mutation Score

### Interpreting Scores

| Score | Interpretation |
|-------|----------------|
| 90-100% | Excellent test suite |
| 75-89% | Good test suite |
| 60-74% | Acceptable, room for improvement |
| Below 60% | Weak test suite, needs attention |

### Score Context Matters

- **High-risk code (90%+):** Payment processing, authentication, data validation
- **Standard code (75%+):** Business logic, API endpoints, data transformations
- **Low-risk code (60%+):** Logging, debug utilities, simple getters/setters

### Why Not 100%?
- Equivalent mutants cannot be killed
- Diminishing returns on last few percent
- More tests = more maintenance

## Analyzing Survived Mutants

### Step-by-Step Process

1. **Review the mutant:**
   ```
   Survived: Line 42: changed > to >=
   Original: if (count > 0)
   Mutant:   if (count >= 0)
   ```
2. **Understand the impact:** What behavior changes when count == 0?
3. **Decide on action:** Add test, mark as equivalent, or accept risk

### Common Survival Patterns

```
# Missing boundary tests
Survives: count > 0 → count >= 0
Fix: Add test for count == 0

# Missing error case tests
Survives: removed throw statement
Fix: Add test that expects exception

# Missing assertion
Survives: return value changed
Fix: Assert on return value, not just no exception
```

## Equivalent Mutants

```python
# Original
def max(a, b):
    if a > b:
        return a
    return b

# Equivalent mutant (same behavior when a == b)
def max(a, b):
    if a >= b:  # EQUIVALENT MUTANT
        return a
    return b
```

**Handling:** Mark as equivalent in tool, configure tool to skip known patterns, or accept score impact.

## Integration Workflow

### When to Run

- **CI Pipeline:** On pull requests (subset or changed files only), nightly full runs, before releases
- **Local Development:** On specific modules you're working on, before marking feature complete

### Performance Optimization

1. **Limit scope:** Test only changed code
2. **Parallel execution:** Run mutants in parallel
3. **Incremental analysis:** Skip unchanged files
4. **Sampling:** Test subset of mutants

### Configuration Example

```yaml
mutation:
  target: src/
  tests: tests/
  timeout_factor: 2.0
  parallel: 4
  skip_patterns:
    - "**/generated/**"
    - "**/migrations/**"
  operators:
    - arithmetic
    - relational
    - logical
```

## Framework-Specific Guidance

### Python (mutmut)

```bash
pip install mutmut
mutmut run
mutmut results
mutmut show 42
```

### JavaScript (Stryker)

```bash
npm install @stryker-mutator/core
npx stryker init
npx stryker run
```

### Java (PIT/Pitest)

```xml
<plugin>
    <groupId>org.pitest</groupId>
    <artifactId>pitest-maven</artifactId>
    <version>1.15.0</version>
</plugin>
```

```bash
mvn org.pitest:pitest-maven:mutationCoverage
```

### Other Frameworks

| Language | Tool | Notes |
|----------|------|-------|
| Python | mutmut | Simple CLI, good integration |
| JavaScript/TypeScript | Stryker | Feature-rich, good reporting |
| Java | PIT | Industry standard for Java |
| C# | Stryker.NET | .NET port of Stryker |
| Ruby | mutant | Semantic mutations |
| Go | go-mutesting | Go support |

## Best Practices

1. **Start Small** — Start with critical modules; expand gradually; focus on high-risk code first
2. **Set Realistic Goals** — Start with current score; set incremental improvement targets
3. **Address Survivors Systematically** — For each survived mutant: equivalent? Mark it. Test missing? Add it. Acceptable risk? Document why.
4. **Integrate with CI** — Run on PRs (limited scope), block on score regression
5. **Balance Cost and Value** — Prioritize critical code; use sampling for large codebases

## Common Pitfalls

1. **Running on Everything** — Full mutation testing takes hours. Target specific modules.
2. **Ignoring Equivalent Mutants** — Review survivors, mark equivalents properly
3. **Adding Tests Without Understanding** — Understand what behavior the mutant changes, test that behavior
4. **Over-Testing to Kill Mutants** — Focus on meaningful mutations, accept some survivors

## Resources

See `resources/` directory for:
- `operator-guide.md` - Detailed mutation operator reference
- `score-interpretation.md` - Understanding and improving scores
- `framework-examples.md` - Framework-specific setup and usage

## Relationship to Other Skills

- `property-based-testing` - Another advanced testing technique
- `test-writing-patterns` - Writing effective tests
- `tdd-refactor-phase` - Improving code with test safety

---
name: command-spec-audit
description: Evaluate command specifications for quality, completeness, and extension point coverage
version: "1.0.0"
frameworkCompatibility: ">=0.60.0"
lastUpdated: "2026-03-17"
license: Complete terms in LICENSE.txt
category: code-quality
invocationMode: direct-only
copyright: "Rubrical Works (c) 2026"
---

# Skill: command-spec-audit

Evaluate command specification files for formatting weaknesses that impact LLM processing reliability. Shared rubric consumed by `/audit-commands`, `/audit-extensions`, and `/extensions` (creation-time guardrail).

**Audience:** Framework maintainers auditing command specs and project developers authoring or reviewing extension point content.

## When to Use

- `/audit-commands` audits command spec structure (framework-only)
- `/audit-extensions` audits extension point content (user-project)
- `/extensions edit` generates extension content from NL input (creation-time guardrail)
- Manually reviewing or authoring a command specification
- Evaluating whether a command spec is ready for deployment

## Evaluation Rubric

Command specs are structured natural-language programs. Headers define scope boundaries, code blocks mark executable literals, bold marks priority signals, tables encode decision matrices. Weaknesses degrade execution reliability, especially after context compaction.

### Category 1: Structural Integrity

| Criterion | Severity | Detection Heuristic | Fix Recommendation |
|-----------|----------|--------------------|--------------------|
| Step granularity | High | Steps with >30 lines and no sub-headers (`####`) | `####` sub-headers for major sub-steps. `**Bold inline labels:**` for lightweight sub-steps. Two-tier pattern matches `/work` (`####`) and `/review-issue` (`**Step 2a:**`). |
| Header hierarchy | Medium | `####` without parent `###`, or `##` jumps | Ensure proper nesting: `##` > `###` > `####` |
| Separator consistency | Low | Inconsistent `---` placement | Standardize: `---` between major `##` sections only |
| Reserved/empty steps | Low | Steps with only "Reserved" or no content | Remove dead steps or add "Reserved for future use" note |
| Section ordering | Medium | Workflow steps not in logical execution order | Reorder to match execution flow |

### Category 2: Decision Formatting

| Criterion | Severity | Detection Heuristic | Fix Recommendation |
|-----------|----------|--------------------|--------------------|
| Branch consistency | Medium | Mix of if/else styles within same command | Standardize: tables for multi-option routing, bold callouts for binary branches |
| Critical branches prominent | Medium | Control flow buried in paragraph text | Extract to table or bold callout: `**If X:** action. **If Y:** action.` |
| Decision matrices as tables | Medium | Multi-option routing in prose or nested bullets | Convert to table: Condition, Action, Notes |
| Condition specificity | Low | Vague conditions like "if needed" | Replace with measurable conditions: "if file count > 10" |

### Category 3: Execution Reliability

| Criterion | Severity | Detection Heuristic | Fix Recommendation |
|-----------|----------|--------------------|--------------------|
| STOP boundary clarity | High | `STOP` in paragraph without visual separation | (a) `### Step N: STOP Boundary — ...` header (preferred), or (b) `**STOP.**` on own line preceded by `---`. |
| Compaction resilience | Medium | Recovery instructions buried in mid-section prose | Add inline recovery note at end of long steps. Dedicated section only for commands >300 lines with multiple recovery points. |
| Code block fencing | High | Shell commands in inline backticks instead of fenced blocks | Wrap all executable commands in triple-backtick fenced blocks |
| Workflow overloading | High when >2 workflows with nested conditionals; Low for binary branching | Single step serving multiple workflows | Preamble scripts preferred for complex routing; inline branching acceptable for simple cases. |
| Error table present | Medium | No error handling section | Add `## Error Handling` table: Situation, Response columns |
| Commit keyword discipline | Medium | Missing `Refs` vs `Fixes` guidance | Add commit keyword table matching project workflow conventions |
| Dynamic progress tracking | Medium | Repeating per-item loop with no todo creation | After item list resolves, create one todo per item. |

### Category 4: Extension Points

| Criterion | Severity | Detection Heuristic | Fix Recommendation |
|-----------|----------|--------------------|--------------------|
| Empty high-value extensions | Low | `pre-commit`, `post-implementation` blocks empty | Normal for new/simple commands. Flag as Medium only if known high-traffic hook with established patterns. |
| Extension formatting | Medium | Content doesn't follow parent command's formatting style | Match parent: same header levels, table style, code block usage |
| Extension conflicts | High | Extension duplicates or contradicts a built-in step | Remove duplication; if intentional override, add comment |
| Extension size | Medium | >50 lines between START/END markers | Refactor large extensions into a called script |
| Cross-extension consistency | Low | Same pattern implemented differently across commands | Standardize: same script call, formatting, error handling |
| Marker integrity | High | Mismatched or missing START/END markers | Fix to `<!-- USER-EXTENSION-START: {point} -->` / `<!-- USER-EXTENSION-END: {point} -->` |

## Severity Guide

| Level | Meaning | Action |
|-------|---------|--------|
| **High** | Degrades LLM execution reliability or causes incorrect behavior | Fix before deployment or next use |
| **Medium** | Reduces clarity or maintainability, may cause issues after compaction | Fix in next revision cycle |
| **Low** | Style consistency, minor readability improvement | Fix opportunistically |

## Output Format

```markdown
### Findings: {command-name}

| # | Criterion | Severity | Location | Finding | Recommendation |
|---|-----------|----------|----------|---------|----------------|
| 1 | Step granularity | High | Step 4 (lines 80-140) | 60 lines with no sub-headers | Split into 3 sub-steps |
| 2 | STOP boundary | High | Line 95 | STOP in paragraph text | Separate with `---` and bold |

**Summary:** 2 High, 1 Medium, 0 Low
```

## Quick Review Checklist

### Structural Integrity
- [ ] No steps exceed 30 lines without sub-headers
- [ ] Header hierarchy is properly nested (## > ### > ####)
- [ ] Separators (`---`) are consistently placed
- [ ] No dead/reserved steps consuming header slots

### Decision Formatting
- [ ] All if/else patterns use consistent format
- [ ] Critical control flow branches are visually prominent
- [ ] Multi-option routing uses tables, not prose
- [ ] Conditions are specific and measurable

### Execution Reliability
- [ ] STOP boundaries are visually distinct
- [ ] Recovery instructions are in scannable, prominent locations
- [ ] All executable commands are in fenced code blocks
- [ ] Steps don't serve multiple workflows without clear routing
- [ ] Error handling table is present

### Extension Points
- [ ] All START/END markers are properly paired
- [ ] Extension content matches parent command formatting
- [ ] No extensions duplicate built-in behavior
- [ ] Large extensions (>50 lines) are refactored to scripts
- [ ] Common patterns are consistent across commands

## Related

- `/audit-commands` — framework-only structural audit
- `/audit-extensions` — user-project extension content audit
- `/extensions edit` — creation-time guardrail using Category 4 criteria
- `anti-pattern-analysis` skill — code-level pattern analysis (complementary)

---
name: sqlite-integration-for-beginners
description: Add SQLite database to Flask or Sinatra app with beginner-friendly code examples and teaching comments
version: "1.0.0"
frameworkCompatibility: ">=0.60.0"
lastUpdated: "2026-03-17"
license: Complete terms in LICENSE.txt
category: database
relevantTechStack: [sqlite, sql, flask, sinatra, python, ruby]
invocationMode: auto
copyright: "Rubrical Works (c) 2026"
---

# SQLite Integration for Beginners

## When to Use This Skill

- User has working app with in-memory storage (lists/arrays)
- User asks "How do I save data permanently?"
- User wants data to persist after server restart
- User mentions "database" but is a beginner
- User has 3-4 features working and is ready for persistence
- File-based or embedded database solutions needed
- Using better-sqlite3 or other SQLite libraries

## Prerequisites Check

- Have working Flask or Sinatra app
- Understand routes and templates
- Have at least one feature using list/array storage
- Understand the "data disappears on restart" problem
- Be comfortable with basic programming concepts

## What is SQLite?

```
SQLite is a database that stores data in a file.

- List/Array: Like writing notes on a whiteboard — fast and easy, disappears when server stops
- SQLite: Like writing in a notebook — data saved to a file (notes.db), stays after server stops

Perfect for beginners because:
✓ No server setup needed
✓ Just a file in your project
✓ Built into Python
✓ Easy to learn SQL basics
✓ Can upgrade to PostgreSQL/MySQL later
```

## Key Concepts to Teach

### 1. Database = Organized Storage
```
Database has TABLES (like spreadsheets)
Each table has:
- COLUMNS: What kind of data (id, name, email)
- ROWS: Actual data entries

Example "notes" table:
┌────┬─────────────────┬────────────────────┐
│ id │ text            │ created_at         │
├────┼─────────────────┼────────────────────┤
│ 1  │ Buy milk        │ 2024-01-15 10:30   │
│ 2  │ Call doctor     │ 2024-01-15 11:45   │
└────┴─────────────────┴────────────────────┘
```

### 2. SQL = Language for Databases
```
CREATE TABLE - Make new table
INSERT INTO  - Add data
SELECT       - Get data
UPDATE       - Change data
DELETE       - Remove data
```

### 3. Connection = Open the Database File
```
1. CONNECT to database file (open it)
2. DO something (add, get, update data)
3. COMMIT (save changes)
4. CLOSE connection (close the file)
```

## Implementation Steps

### Step 1: Understand the Transition

**Current code (using list):**
```python
notes = []  # Data in RAM - disappears when server stops

@app.route('/')
def home():
    return render_template('index.html', notes=notes)
```

**After adding SQLite:** Data saved in `notes.db` file → persists forever

### Step 2: Choose Your Framework

- **Flask users:** See `resources/flask-sqlite-example.py`
- **Sinatra users:** See `resources/sinatra-sqlite-example.rb`
- **SQL basics:** See `resources/sql-basics.md`

## Flask Implementation

**1. Import sqlite3:**
```python
import sqlite3
```

**2. Create connection function:**
```python
def get_db():
    conn = sqlite3.connect('notes.db')
    conn.row_factory = sqlite3.Row
    return conn
```

**3. Initialize database:**
```python
def init_db():
    conn = get_db()
    conn.execute('''
        CREATE TABLE IF NOT EXISTS notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            text TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()
```

**4. Update routes:**
```python
@app.route('/')
def home():
    conn = get_db()
    notes = conn.execute('SELECT * FROM notes').fetchall()
    conn.close()
    return render_template('index.html', notes=notes)
```

## Sinatra Implementation

**1. Require sqlite3:**
```ruby
require 'sqlite3'
```

**2. Create database connection:**
```ruby
DB = SQLite3::Database.new 'notes.db'
DB.results_as_hash = true
```

**3. Create table:**
```ruby
DB.execute <<-SQL
  CREATE TABLE IF NOT EXISTS notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  )
SQL
```

**4. Update routes:**
```ruby
get '/' do
  @notes = DB.execute('SELECT * FROM notes')
  erb :index
end
```

## Teaching Approach: Explain Each SQL Statement

**CREATE TABLE explanation:**
```
- CREATE TABLE notes: Make a new table called "notes"
- IF NOT EXISTS: Only if it doesn't already exist (safe to run multiple times)
- id INTEGER PRIMARY KEY AUTOINCREMENT: Unique number, automatically increments
- text TEXT NOT NULL: Column for note content, must have a value
- created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP: Automatically filled with current time
```

**INSERT explanation:**
```
INSERT INTO notes (text) VALUES (?)
- The ? is a placeholder (safer than putting text directly)
- We pass actual text separately to prevent SQL injection
```

**SELECT explanation:**
```
SELECT * FROM notes ORDER BY created_at DESC
- SELECT *: Get all columns
- ORDER BY created_at DESC: Sort newest first
```

## Common Questions

**Q: Where is the database file?** In your project folder: `notes.db`.

**Q: Can I look inside?** Yes — DB Browser for SQLite (free, visual), sqlite3 command line, VS Code extensions.

**Q: What if I make a mistake?** Delete `notes.db` file. It will recreate on next run (but data is lost).

**Q: Do I need to install SQLite?** Python: Built-in. Ruby: `gem install sqlite3`.

**Q: What about SQL injection?** We use `?` placeholders (prepared statements). Never put user input directly in SQL!

## Testing the Database

1. Add note through form, restart server, check if note still there
2. Look in project folder — `notes.db` file should exist
3. Add several notes, restart server — all should persist
4. Delete `notes.db`, start server — new empty database created

## Migration Path

- **Phase 1:** Basic SQLite — single table, simple queries
- **Phase 2:** Multiple tables — users and notes, foreign keys
- **Phase 3:** Complex queries, JOIN operations, indexes
- **Phase 4:** PostgreSQL or MySQL for production (same SQL concepts apply)

## Troubleshooting

- `sqlite3.OperationalError: no such table` → Run `init_db()`, check if `CREATE TABLE` ran
- `Database is locked` → Close DB Browser or other tools, restart server
- `No such column` → Typo in column name, check exact spelling in SQL
- Template shows weird data format → Access dict/Row correctly; see framework examples

## Complete Examples

- `resources/flask-sqlite-example.py`
- `resources/sinatra-sqlite-example.rb`
- `resources/sql-basics.md`

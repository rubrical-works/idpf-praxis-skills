---
name: tdd-refactor-phase
description: Guide experienced developers through REFACTOR phase of TDD cycle - improving code quality while maintaining green tests
version: "1.0.0"
frameworkCompatibility: ">=0.60.0"
lastUpdated: "2026-03-17"
license: Complete terms in LICENSE.txt
category: testing
relevantTechStack: [tdd, jest, vitest, pytest, go, rust, rspec, testing]
invocationMode: auto
defaultSkill: true
copyright: "Rubrical Works (c) 2026"
---

# TDD REFACTOR Phase

## When to Use This Skill

- GREEN phase complete with passing test
- Proceeding autonomously from GREEN phase
- Code works but could be improved
- Evaluating refactoring opportunities

## Prerequisites

- Completed GREEN phase with all tests passing
- Working implementation that satisfies test requirements
- Full test suite available to verify refactoring safety
- Claude Code available for analysis and execution

## REFACTOR Phase Objectives

1. **Improve code quality** - Make code cleaner, more maintainable, better structured
2. **Keep tests green** - Ensure all improvements maintain existing functionality

**Refactoring IS:** Improving code structure without changing behavior; making code more readable; eliminating duplication; simplifying complex logic; improving naming.
**Refactoring IS NOT:** Adding new features; changing tested behavior; fixing bugs (that's a new test + implementation); performance optimization without measurement; breaking tests to "improve" code.

## REFACTOR Phase Workflow

### Step 1: Analyze Refactoring Opportunities

Identify: code duplication, long or complex functions, unclear variable/function names, missing abstractions, violation of design principles (SOLID, DRY), complex conditional logic, magic numbers/strings.

### Step 2: Evaluate Refactoring Suggestions

**Refactor Now:** Clear improvement opportunity, low risk/high value, directly improves code, won't over-engineer solution.
**Skip Refactoring:** Premature abstraction, risk > reward, better addressed in future iteration, code already clear enough.

### Step 3: Apply Refactoring (if approved)

1. Apply the refactored code
2. Run full test suite
3. Verify ALL tests still pass

### Step 4: Verify Tests Remain Green

Run FULL test suite — ALL tests must pass, no failures, no errors.

**If any test fails:** → Refactoring broke something → Rollback refactoring immediately → Keep tests green → Try smaller refactoring

### Step 5: Complete REFACTOR Phase

**If refactoring applied and tests green:** → Code improved and safe → Proceed to next behavior or complete story
**If refactoring skipped:** → REFACTOR phase complete (no changes) → Proceed to next behavior

**TDD cycle continues autonomously** until story implementation is complete. Only checkpoint is story completion (In Review → Done).

## REFACTOR Phase Best Practices

### Practice 1: Refactor in Small Steps

```
Good:
1. Extract one variable → Run tests
2. Rename one function → Run tests
3. Extract one function → Run tests

Poor:
1. Extract variables + rename + restructure all at once
2. Run tests
3. Multiple failures, unclear which change broke what
```

### Practice 2: One Refactoring at a Time

Focus on one improvement, run tests, then next refactoring.

### Practice 3: Keep Tests Green

```
Tests must ALWAYS be green after refactoring.

If refactoring breaks tests:
→ Rollback immediately
→ Try smaller refactoring
```

### Practice 4: Refactor for Clarity, Not Cleverness

Good: Makes code easier to understand, reduces cognitive load, improves maintainability.
Poor: Clever one-liners that obscure intent, over-abstracted solutions, premature design patterns.

## Common Refactorings

**Extract Variable:** Assign embedded expression to well-named variable; intent clear from variable name.

**Extract Function:** Extract logic from long function to well-named function that does one clear thing.

**Rename for Clarity:** Replace unclear names, abbreviations, or generic names with intent-expressing names.

**Eliminate Duplication:** Extract duplicated code to function — single source of truth.

**Simplify Conditional Logic:** Guard clauses reduce nesting; early returns simplify flow; extract boolean expressions with clear names.

## When to Skip Refactoring

| Scenario | Indicators | Decision |
|----------|-----------|----------|
| Premature Abstraction | Only one use, future needs unclear, abstraction more complex than original | Skip — wait for third occurrence |
| Code Already Clear | Minor naming changes suggested, current names already descriptive | Skip |
| High Risk, Low Value | Touches many files, complex change for minor improvement | Skip or Defer |
| Over-Engineering | Design patterns for single use case, "might need this later" | Skip |

## REFACTOR Phase Anti-Patterns

```
✗ WRONG: Make changes → Hope nothing broke
✓ CORRECT: Make changes → Run tests → Verify green → Proceed

✗ WRONG: Refactor → Tests fail → "I'll fix tests later"
✓ CORRECT: Refactor → Tests fail → ROLLBACK → Tests green again

✗ WRONG: Change everything at once; tests fail; don't know which change broke what
✓ CORRECT: Small incremental changes; test after each; identify exactly what breaks

✗ WRONG: Refactor existing code + add new feature simultaneously
✓ CORRECT: Refactor (tests stay green) OR add feature (new test) — never both at same time
```

## Integration with IDPF-Agile

REFACTOR phase follows GREEN in story implementation. When `/work` triggers TDD:
1. GREEN phase verified — tests passing
2. Analyze code for refactoring opportunities
3. Either apply refactoring or skip with reason
4. Run tests, verify green
5. Proceed to next behavior or complete story

The TDD cycle runs autonomously. The only user checkpoint is at story completion (In Review → Done).

## Rollback Procedures

**If refactoring breaks tests:**
1. Immediate action: Rollback changes (git checkout or undo)
2. Verify: Tests return to green
3. Options: Try smaller refactoring, skip refactoring for now, or investigate why tests broke

**Rollback is immediate** — revert broken changes and maintain green tests throughout.

## REFACTOR Phase Checklist

- [ ] Code analyzed for refactoring opportunities
- [ ] Suggestions evaluated
- [ ] If refactoring applied:
  - [ ] Refactored code is clear and improved
  - [ ] All tests run and PASS (green)
  - [ ] No test failures or errors
  - [ ] Behavior unchanged
- [ ] If refactoring skipped:
  - [ ] Valid reason for skipping
  - [ ] Tests still green

## Resources

See `resources/` directory for:
- `refactor-checklist.md` - Quick reference checklist
- `common-refactorings.md` - Catalog of common refactoring patterns
- `when-to-skip-refactoring.md` - Decision guide for skipping refactoring

## Relationship to Other Skills

- `tdd-green-phase` - Previous phase with passing tests
- `tdd-red-phase` - Next feature starts new RED phase
- `tdd-failure-recovery` - Handle broken tests during refactoring

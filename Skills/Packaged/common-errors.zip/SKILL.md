---
name: common-beginner-coding-errors
description: Diagnose and solve common beginner programming mistakes in Flask or Sinatra development with detailed explanations
version: "1.0.0"
frameworkCompatibility: ">=0.60.0"
lastUpdated: "2026-03-17"
license: Complete terms in LICENSE.txt
category: debugging
relevantTechStack: [flask, sinatra, python, ruby]
invocationMode: auto
copyright: "Rubrical Works (c) 2026"
---

# Common Beginner Coding Errors

This Skill helps beginners diagnose and fix the most common errors encountered when learning Flask or Sinatra web development.

## When to Use This Skill

- Beginner reports an error message
- Code isn't working as expected
- User asks "Why isn't this working?"
- Application crashes unexpectedly
- Need help reading exception messages or stack traces
- Framework-specific errors (Flask, Sinatra, Python, Ruby)

## How to Use This Skill

1. **Identify the error** from user's report
2. **Find the matching error pattern** below
3. **Apply the solution** with explanation
4. **Verify the fix** worked

## Common Errors by Category

### 1. File Management Errors

#### Error: Changes Don't Appear When Refreshing Browser

**Diagnosis:** Ask the user: Did you save the file? Did you restart the server? Are you editing the correct file?

**Solution 1: File Not Saved**
```
Look at editor's file tab — dot (●) or asterisk (*) means unsaved.
Press Ctrl+S (Windows/Linux) or Cmd+S (Mac).
Pro tip: Edit → Save → Test → Repeat
```

**Solution 2: Server Not Restarted (Sinatra)**
```
Sinatra doesn't auto-reload by default.
Press Ctrl+C → run: ruby app.rb → refresh browser.
Flask users: Make sure debug=True is set for auto-reload.
```

**Solution 3: Browser Cache**
```
Hard refresh: Windows/Linux: Ctrl+Shift+R | Mac: Cmd+Shift+R | Or: Ctrl+F5
```

#### Error: Template Not Found

- Flask: `TemplateNotFound: index.html`
- Sinatra: `Errno::ENOENT: No such file or directory @ rb_sysopen - views/index.erb`

**Flask — correct structure:**
```
my-project/
├── app.py
└── templates/      ← Must be named exactly "templates"
    └── index.html
```
Common mistakes: `template/` (missing 's'), `Templates/` (wrong capitalization), HTML in project root.

**Sinatra — correct structure:**
```
my-project/
├── app.rb
└── views/          ← Must be named exactly "views"
    └── index.erb
```

### 2. Python-Specific Errors

#### Error: IndentationError

```
IndentationError: expected an indented block
IndentationError: unindent does not match any outer indentation level
```

**Wrong:**
```python
def my_function():
print("hello")  # Not indented!
```

**Right:**
```python
def my_function():
    print("hello")  # Indented 4 spaces
```

**Solution:** Use 4 spaces for each indentation level. Don't mix tabs and spaces. Configure editor to insert 4 spaces when you press Tab.

#### Error: ModuleNotFoundError: No module named 'flask'

**Solution 1: Virtual Environment Not Activated**
```
Look at terminal prompt:
✗ Wrong:  C:\Projects\my-app>
✓ Correct: (venv) C:\Projects\my-app>

Windows: venv\Scripts\activate
Mac/Linux: source venv/bin/activate
```

**Solution 2: Flask Not Installed**
```
pip install flask
pip list | grep -i flask  (Mac/Linux)
pip list | findstr /i flask  (Windows)
```

**Solution 3: Running Wrong Python**
```
which python  (Mac/Linux) or where python  (Windows)
Should point to: .../my-project/venv/Scripts/python.exe
```

### 3. Ruby/Sinatra-Specific Errors

#### Error: uninitialized constant Sinatra (NameError)

```
Step 1: bundle list | grep sinatra
If not listed: check Gemfile has gem 'sinatra', then run: bundle install

Step 2: File must start with: require 'sinatra'

Step 3: Run with bundler
Instead of: ruby app.rb
Use: bundle exec ruby app.rb
```

### 4. Route/URL Errors

#### Error: 404 Not Found

**Cause 1: Typo in URL** — Routes are case-sensitive: `/About ≠ /about`

**Cause 2: Route Not Defined**
```python
# Flask
@app.route('/about')
def about():
    return "About page"
```
```ruby
# Sinatra
get '/about' do
  "About page"
end
```

**Cause 3: Wrong HTTP Method**
```python
# Flask fix
@app.route('/add', methods=['GET', 'POST'])
```
```ruby
# Sinatra fix
post '/add' do
  # Handle POST only
end
```

### 5. Server Errors

#### Error: Address Already in Use

- Flask: `OSError: [Errno 48] Address already in use`
- Sinatra: `Address already in use - bind(2)`

**Solution 1:** Find other terminal windows with server running → press Ctrl+C → retry.

**Solution 2: Kill the Process**
```bash
# Mac/Linux
lsof -i :5000
kill <PID>

# Windows
netstat -ano | findstr :5000
taskkill /PID <PID> /F
```

**Solution 3: Use Different Port**
```python
# Flask
app.run(debug=True, port=5001)
```
```ruby
# Sinatra
set :port, 4568
```

### 6. Function/Route Errors

#### Error: Nothing Returned from Route

**Flask - Wrong:**
```python
@app.route('/')
def home():
    notes = get_notes()
    # Forgot to return something!
```

**Flask - Right:**
```python
@app.route('/')
def home():
    notes = get_notes()
    return render_template('index.html', notes=notes)
```

**Sinatra - Right:**
```ruby
get '/' do
  @notes = get_notes
  erb :index
end
```

## Error Diagnosis Process

### Step 1: Get Complete Error Information
```
Ask for:
1. Exact error message (full text, not summary)
2. Which file/line number
3. What they were trying to do
4. Output from terminal
```

### Step 2: Identify Error Category
```
"IndentationError"      → Python indentation
"TemplateNotFound"      → File location
"ModuleNotFoundError"   → Import/installation
"404"                   → Route/URL problem
"Address already in use" → Port conflict
"NameError"             → Missing variable/constant
```

### Step 3: Guide to Solution
1. Explain what caused the error (use analogies)
2. Show exact steps to fix
3. Explain why fix works
4. Have user verify fix worked

### Step 4: Teach Prevention
After fixing, explain how to avoid this error in future, what to look for, and best practices.

## Additional Resources

- See `resources/flask-errors.md` for Flask-specific issues
- See `resources/sinatra-errors.md` for Sinatra-specific issues
- See `resources/general-errors.md` for language-agnostic issues

## Debugging Mindset for Beginners

```
1. Read the Error — error messages are helpful, not scary
2. Find the Location — error shows file and line number
3. Form a Hypothesis — what might be wrong?
4. Test the Hypothesis — make one small change, test
5. Learn from It — you're building debugging skills
```

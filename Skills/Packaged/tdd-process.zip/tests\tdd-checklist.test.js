/**
 * Validates tdd-checklist.json + tdd-checklist-schema.json.
 *
 * Run with: node tests/tdd-checklist.test.js
 *
 * Uses a tiny inline JSON Schema validator (the same subset used by the
 * tdd-refactor-coverage-audit skill: type, required, properties,
 * additionalProperties, items, $ref, $defs/definitions, minItems, minLength,
 * minProperties).
 *
 * Plus a soft-skip simulation: confirms that the orchestrator's "is the
 * audit script installed?" probe works as a simple fs.existsSync check
 * with no fallback paths.
 */

'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');

const SKILL_DIR = path.resolve(__dirname, '..');
const SCHEMA_PATH = path.join(SKILL_DIR, 'tdd-checklist-schema.json');
const CHECKLIST_PATH = path.join(SKILL_DIR, 'tdd-checklist.json');
const FIX_DIR = path.join(__dirname, 'fixtures');

const schema = JSON.parse(fs.readFileSync(SCHEMA_PATH, 'utf8'));

function loadFixture(name) {
  return JSON.parse(fs.readFileSync(path.join(FIX_DIR, name), 'utf8'));
}

// ---------- minimal JSON Schema validator ----------
function resolveRef(root, ref) {
  if (!ref.startsWith('#/')) throw new Error('Only local $ref supported: ' + ref);
  const parts = ref.slice(2).split('/');
  let cur = root;
  for (const p of parts) cur = cur[p];
  return cur;
}

function validate(node, data, root, p, errors) {
  if (!node) return;
  if (node.$ref) return validate(resolveRef(root, node.$ref), data, root, p, errors);
  if (node.type) {
    const t = node.type;
    const ok =
      (t === 'object' && data !== null && typeof data === 'object' && !Array.isArray(data)) ||
      (t === 'array' && Array.isArray(data)) ||
      (t === 'string' && typeof data === 'string') ||
      (t === 'number' && typeof data === 'number') ||
      (t === 'integer' && Number.isInteger(data)) ||
      (t === 'boolean' && typeof data === 'boolean');
    if (!ok) {
      errors.push(`${p || '<root>'}: expected type ${t}`);
      return;
    }
  }
  if (node.type === 'object') {
    if (Array.isArray(node.required)) {
      for (const k of node.required) {
        if (!(k in data)) errors.push(`${p || '<root>'}: missing required '${k}'`);
      }
    }
    if (node.properties) {
      for (const [k, sub] of Object.entries(node.properties)) {
        if (k in data) validate(sub, data[k], root, p ? `${p}.${k}` : k, errors);
      }
    }
    if (node.additionalProperties === false) {
      const known = new Set(Object.keys(node.properties || {}));
      for (const k of Object.keys(data)) {
        if (!known.has(k)) errors.push(`${p || '<root>'}: unexpected property '${k}'`);
      }
    }
  }
  if (node.type === 'array') {
    if (typeof node.minItems === 'number' && data.length < node.minItems) {
      errors.push(`${p}: minItems ${node.minItems}`);
    }
    if (node.items) data.forEach((it, i) => validate(node.items, it, root, `${p}[${i}]`, errors));
  }
  if (node.type === 'string' && typeof node.minLength === 'number') {
    if (data.length < node.minLength) errors.push(`${p}: minLength ${node.minLength}`);
  }
}

function validateAgainstSchema(data) {
  const errors = [];
  validate(schema, data, schema, '', errors);
  return errors;
}

const tests = [];
function test(name, fn) { tests.push({ name, fn }); }

// ---------- schema fixture tests ----------

test('schema accepts the bundled tdd-checklist.json', () => {
  const data = JSON.parse(fs.readFileSync(CHECKLIST_PATH, 'utf8'));
  const errors = validateAgainstSchema(data);
  assert.deepStrictEqual(errors, []);
});

test('schema accepts single-object deepReference (legacy form)', () => {
  const errors = validateAgainstSchema(loadFixture('checklist-with-deepReference.json'));
  assert.deepStrictEqual(errors, []);
});

test('schema accepts deepReferences[] array form', () => {
  const errors = validateAgainstSchema(loadFixture('checklist-with-deepReferences.json'));
  assert.deepStrictEqual(errors, []);
});

test('schema accepts phase with neither deepReference nor deepReferences', () => {
  const errors = validateAgainstSchema(loadFixture('checklist-no-references.json'));
  assert.deepStrictEqual(errors, []);
});

test('schema rejects invalid deepReference (empty skill)', () => {
  const errors = validateAgainstSchema(loadFixture('checklist-invalid-deepReference.json'));
  assert.ok(errors.length > 0, 'expected validation errors, got none');
});

test('bundled checklist refactor phase uses deepReferences[] with both skills', () => {
  const data = JSON.parse(fs.readFileSync(CHECKLIST_PATH, 'utf8'));
  assert.ok(Array.isArray(data.refactor.deepReferences));
  const skills = data.refactor.deepReferences.map((d) => d.skill).sort();
  assert.deepStrictEqual(skills, ['tdd-refactor-coverage-audit', 'tdd-refactor-phase']);
});

test('bundled checklist refactor phase has audit checklist item', () => {
  const data = JSON.parse(fs.readFileSync(CHECKLIST_PATH, 'utf8'));
  const hasAudit = data.refactor.required.some((s) => /test-coverage-audit\.js/.test(s));
  assert.ok(hasAudit, 'refactor.required[] should reference test-coverage-audit.js');
});

// ---------- soft-skip simulation ----------
//
// The orchestrator detects whether the audit skill is installed via a
// simple fs.existsSync on the script path. These tests confirm the probe
// works correctly in both states without any fallback or error escalation.

const AUDIT_SCRIPT_REL = '.claude/skills/tdd-refactor-coverage-audit/scripts/test-coverage-audit.js';

function probeInstalled(projectRoot) {
  return fs.existsSync(path.join(projectRoot, AUDIT_SCRIPT_REL));
}

test('soft-skip: probe returns false when audit script is absent', () => {
  const tmp = fs.mkdtempSync(path.join(require('os').tmpdir(), 'tdd-process-'));
  try {
    assert.strictEqual(probeInstalled(tmp), false);
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
});

test('soft-skip: probe returns true when audit script is present', () => {
  const tmp = fs.mkdtempSync(path.join(require('os').tmpdir(), 'tdd-process-'));
  try {
    const dir = path.join(tmp, '.claude/skills/tdd-refactor-coverage-audit/scripts');
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, 'test-coverage-audit.js'), '// stub');
    assert.strictEqual(probeInstalled(tmp), true);
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
});

test('soft-skip: probe never throws on missing intermediate directories', () => {
  const tmp = fs.mkdtempSync(path.join(require('os').tmpdir(), 'tdd-process-'));
  try {
    // No .claude dir at all
    assert.doesNotThrow(() => probeInstalled(tmp));
    assert.strictEqual(probeInstalled(tmp), false);
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
});

// ---------- runner ----------

let passed = 0;
let failed = 0;
const failures = [];
for (const t of tests) {
  try {
    t.fn();
    passed++;
  } catch (e) {
    failed++;
    failures.push({ name: t.name, error: e.message });
  }
}
console.log(`\n${passed} passed, ${failed} failed (${tests.length} total)`);
if (failed > 0) {
  for (const f of failures) console.log(`  FAIL ${f.name}\n    ${f.error}`);
  process.exit(1);
}

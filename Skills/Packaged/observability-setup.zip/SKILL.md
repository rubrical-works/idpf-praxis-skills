---
name: observability-setup
description: Scaffold observability infrastructure including OpenTelemetry SDK config, Grafana dashboards, alert rules, and structured logging setup
version: "1.0.0"
frameworkCompatibility: ">=0.60.0"
lastUpdated: "2026-03-17"
license: Complete terms in LICENSE.txt
category: devops
relevantTechStack: [opentelemetry, grafana, prometheus, logging, metrics, tracing]
invocationMode: auto
copyright: "Rubrical Works (c) 2026"
---

# Observability Setup

Scaffolds observability infrastructure: structured logging, distributed tracing, metrics collection, and alerting templates for production services.

**Companion Domain:** Domains/Observability — provides evaluative review criteria

## When to Use This Skill

- Setting up structured logging for a new service
- Configuring OpenTelemetry SDK for tracing and metrics
- Creating Grafana dashboard templates or SLO-based alert rules
- Establishing a metrics naming convention

## Scaffolding Capabilities

### OpenTelemetry SDK Configuration
- Tracer and meter provider setup with sampling strategy and export interval
- Context propagation (W3C TraceContext)
- Resource attributes (service name, version, environment)

### Structured Logging Setup
- JSON log formatter; log level mapping (ERROR, WARN, INFO, DEBUG)
- Correlation ID middleware; PII redaction patterns

### Grafana Dashboard Templates
- RED metrics dashboard (Rate, Errors, Duration)
- Service overview, endpoint latency percentiles (p50, p95, p99)
- Error rate breakdown by status code

### Alert Rule Scaffolding
- SLO-based burn rate, error rate, latency p99 threshold alerts
- Alert routing and severity classification

## Related Skills
- `ci-cd-pipeline-design` — deploying observability configuration
- `error-handling-patterns` — consistent error logging and classification

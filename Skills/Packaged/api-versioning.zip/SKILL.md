---
name: api-versioning
description: Guide developers through API versioning strategies, deprecation workflows, and backward compatibility patterns
version: "1.0.0"
frameworkCompatibility: ">=0.60.0"
lastUpdated: "2026-03-17"
license: Complete terms in LICENSE.txt
category: architecture
relevantTechStack: [rest, graphql, api, node, express]
invocationMode: auto
copyright: "Rubrical Works (c) 2026"
---

# API Versioning

This Skill guides developers through API versioning strategies including URL-based, header-based, and content negotiation approaches, along with deprecation workflows and backward compatibility patterns.

## When to Use This Skill

- Designing a new API that will evolve over time
- Planning breaking changes to an existing API
- Establishing deprecation policies
- Migrating clients between API versions
- Choosing between versioning strategies

## Versioning Strategies

### 1. URL Path Versioning

```
/api/v1/users
/api/v2/users
```

**Pros:** Highly visible, easy to route and cache, simple client implementation
**Cons:** URL pollution, can't version resources individually, requires URL changes on upgrade
**Best for:** Public APIs, major version changes, simple versioning needs

### 2. Query Parameter Versioning

```
/api/users?version=1
/api/users?api-version=2024-01-01
```

**Pros:** Optional (can default), single URL structure, easy to add to existing APIs
**Cons:** Easy to miss, can interfere with caching
**Best for:** Optional versioning, date-based versions, gradual introduction

### 3. Header Versioning

```
GET /api/users
Accept-Version: v1
```

**Pros:** Clean URLs, follows HTTP semantics, per-request versioning
**Cons:** Harder to test in browser, less visible, requires header manipulation
**Best for:** Internal APIs, fine-grained versioning

### 4. Content Negotiation (Media Type)

```
GET /api/users
Accept: application/vnd.company.users.v2+json
```

**Pros:** RESTful approach, can version representations separately
**Cons:** Complex implementation, harder for clients
**Best for:** Strict REST APIs, enterprise environments

## Choosing a Strategy

### Decision Matrix

| Factor | URL Path | Query Param | Header | Media Type |
|--------|----------|-------------|--------|------------|
| Visibility | High | Medium | Low | Low |
| Simplicity | High | High | Medium | Low |
| RESTful | Medium | Low | Medium | High |
| Caching | Easy | Medium | Complex | Complex |
| Testing | Easy | Easy | Medium | Hard |

### Recommendations by Context

- **Public APIs:** URL path versioning — most discoverable
- **Internal APIs:** Header versioning — cleaner URLs
- **Enterprise APIs:** Media type versioning — follows standards
- **Simple APIs:** Query parameter — easy to add

## Version Numbering

### Semantic Versioning
```
MAJOR.MINOR.PATCH
MAJOR: Breaking changes
MINOR: Backward-compatible additions
PATCH: Backward-compatible fixes
```

### Date-Based Versioning
```
YYYY-MM-DD or YYYY-MM
```
Use when: frequent releases, rolling deprecation windows (Azure/AWS style).

### Simple Major Versioning
```
v1, v2, v3
```
Use when: infrequent major changes, clear breaking changes.

## Backward Compatibility

**Safe changes (usually compatible):**
- Adding new endpoints
- Adding optional parameters
- Adding new response fields
- Adding new enum values (if client handles unknown)

**Breaking changes (require new version):**
- Removing endpoints or response fields
- Changing field types or names
- Changing required parameters
- Changing authentication

### Compatibility Patterns

```json
// v1 response
{"id": 1, "name": "Alice"}

// v1.1 response (compatible - added field)
{"id": 1, "name": "Alice", "email": "alice@example.com"}
```

## Deprecation Workflow

### Deprecation Lifecycle
```
Active → Deprecated → Sunset → Removed
```

### Deprecation Header
```
Deprecation: true
Sunset: Sat, 01 Jun 2025 00:00:00 GMT
Link: <https://api.example.com/docs/migration>; rel="deprecation"
```

### Timeline Example
```
Month 0:  Announce v1 deprecation, v2 released
Month 1:  Add deprecation headers to v1
Month 3:  Start warning notifications
Month 6:  Enter sunset period
Month 9:  Remove v1 (or extend if needed)
```

## Client Migration

### Migration Guide Template

```markdown
# Migration Guide: v1 to v2

## Overview
- v2 released: [date]
- v1 sunset: [date]
- v1 removal: [date]

## Breaking Changes
1. [Change description]
   - Before: [v1 behavior]
   - After: [v2 behavior]
   - Migration: [steps]

## New Features in v2
- [Feature 1]

## Step-by-Step Migration
1. [Step 1]

## FAQ
Q: [Common question]
A: [Answer]
```

### Gradual Migration Strategies

**Shadow testing:** Client sends to v1; server also sends to v2 internally; compare responses; when confident, switch client to v2.

**Feature flags:**
```
const API_VERSION = process.env.USE_V2_API ? 'v2' : 'v1';
```

## REST API Patterns

**Version the API, not resources:**
```
/api/v1/users      ✓
/api/v1/products   ✓
/api/users/v1      ✗ (inconsistent)
```

**Envelope pattern:**
```json
{
  "data": { ... },
  "meta": { "version": "1.2.0", "deprecated": false }
}
```

## GraphQL Patterns

GraphQL naturally supports additive changes. For breaking changes:
```
/graphql       # Current version
/graphql/v2    # New version with breaking changes
```

**Deprecating fields:**
```graphql
type User {
  name: String! @deprecated(reason: "Use fullName instead")
  fullName: String!
}
```

## Implementation Checklist

### Before Releasing Versioned API
- [ ] Versioning strategy chosen
- [ ] Version numbering scheme defined
- [ ] Documentation includes version information
- [ ] Deprecation policy documented
- [ ] Client SDKs version-aware

### When Deprecating
- [ ] Deprecation announced
- [ ] Migration guide written
- [ ] Deprecation headers added
- [ ] Sunset date set
- [ ] Usage monitoring in place

### When Removing
- [ ] All clients migrated (or accepted)
- [ ] Logs show minimal traffic
- [ ] Final notifications sent
- [ ] Old version documentation archived
- [ ] Redirects or error messages in place

## Resources

See `resources/` directory for:
- `strategy-comparison.md` - Detailed strategy analysis
- `deprecation-workflow.md` - Step-by-step deprecation process
- `compatibility-guide.md` - Backward compatibility patterns

## Relationship to Other Skills

- `error-handling-patterns` - API error responses
- `postgresql-integration` - Backend data evolution

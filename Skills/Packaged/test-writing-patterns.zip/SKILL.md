---
name: test-writing-patterns
description: Guide experienced developers on test structure, patterns, assertions, and test doubles for effective test-driven development
version: "1.0.0"
frameworkCompatibility: ">=0.60.0"
lastUpdated: "2026-03-17"
license: Complete terms in LICENSE.txt
category: testing
relevantTechStack: [jest, vitest, pytest, go, rust, rspec, testing, tdd, mocking]
invocationMode: auto
defaultSkill: true
copyright: "Rubrical Works (c) 2026"
---

# Test Writing Patterns

## When to Use This Skill

- User needs guidance on test structure
- Questions about test organization
- Deciding which type of test to write
- Need test double (mock/stub/fake) guidance
- Uncertainty about assertion strategies
- Want to improve test quality and maintainability

## Prerequisites

- Understanding of testing concepts
- Familiarity with TDD RED-GREEN-REFACTOR cycle
- Experience with at least one testing framework

## Test Structure Patterns

### AAA Pattern (Arrange-Act-Assert)

```
ARRANGE: Set up test conditions and inputs
ACT: Execute the behavior being tested
ASSERT: Verify the expected outcome
```

Benefits: Clear separation of concerns, easy to read, consistent structure, self-documenting.

### Given-When-Then Pattern (BDD Style)

```
GIVEN: Initial context/preconditions
WHEN: Action/event occurs
THEN: Expected outcomes
```

Maps directly to AAA (GIVEN=ARRANGE, WHEN=ACT, THEN=ASSERT). Natural language alignment; behavior-focused.

### Four-Phase Test Pattern

```
SETUP: Prepare test fixture
EXERCISE: Execute system under test
VERIFY: Check results
TEARDOWN: Clean up resources
```

Use for: tests with expensive setup, tests requiring cleanup (files, connections), integration tests.

## Test Organization Strategies

### Test File Organization

Mirror production structure:
```
src/services/user_service → tests/services/test_user_service
src/utils/validator → tests/utils/test_validator
```

### Test Naming Conventions

Pattern: `test_[unit]_[scenario]_[expected]`

```
test_add_positive_numbers_returns_sum
test_get_user_when_not_found_returns_null
test_create_order_with_invalid_data_raises_exception
```

### Test Suite Organization

By type: `tests/unit/`, `tests/integration/`, `tests/e2e/`, `tests/performance/`
By feature: `tests/user_management/`, `tests/order_processing/`, etc.

## Assertion Strategies

### Single Concept Per Test

**Good:** One assertion or set of closely related assertions (e.g., all verifying user creation properties).
**Poor:** Multiple unrelated assertions (e.g., create + update + delete + list in one test — split these).

### Assertion Quality

**Good assertions:** Specific and precise, include helpful messages, test observable behavior, independent of implementation details.
**Poor assertions:** Generic (just assert True), no context when failing, test internal state, coupled to implementation.

### Common Assertion Types

```
assert actual == expected
assert value is not null
assert value > 0
assert item in collection
assert raises(ExpectedException)
assert isinstance(obj, ExpectedType)
```

## Test Doubles

### Selection Guide

```
Need to control response? → Stub
Need to verify call made? → Mock
Need working but simple version? → Fake
Need real behavior + verification? → Spy
```

### Stub

Provides predetermined responses. No behavior verification. Use to: control dependency behavior, isolate unit under test, avoid external dependencies.

### Mock

Records calls made to it. Verifies expectations. Use to: verify method was called, check call parameters, verify call count/order.

### Fake

Working but simplified implementation. Actually executes logic. Use for: in-memory databases, fake file systems, fake message queues.

### Spy

Wraps real object, records calls, delegates to real implementation. Use to: observe interactions while keeping real behavior.

## Test Isolation

**Each test should:** Set up its own data, clean up after itself, run in any order, not depend on other tests.

```
Before each test:
  - Create fresh test data
  - Reset state
  - Initialize dependencies

After each test:
  - Clean up resources
  - Remove test data
  - Close connections
```

**Database isolation:** Use transactions (rollback after test), separate test database, clear data between tests, or use in-memory database.

## Test Data Strategies

**Explicit over random:**
```
Good: user = create_user(name="Alice", age=30)   // Clear what data represents
Poor: user = create_user(name=random_string())   // Non-deterministic
```

**Minimal test data:** Use simplest data that tests the behavior; avoid irrelevant fields.

**Test Data Builders:**
```
user = UserBuilder().with_name("Alice").with_role("admin").build()
```
Benefits: readable, defaults for irrelevant fields, explicit about what matters.

## Testing Strategies by Type

**Unit Tests:** Single unit, fast execution, no external dependencies, use test doubles. Focus: logic correctness, edge cases, error handling.

**Integration Tests:** Multiple units together, may use real dependencies, slower. Focus: interface contracts, data flow, error propagation.

**End-to-End Tests:** Complete user workflows, real system, slowest, highest confidence. Focus: critical user paths, business scenarios.

## Test Coverage Considerations

**Coverage metrics:** Line, branch, function, statement coverage.

**Coverage ≠ Quality:** 100% coverage doesn't mean all behaviors tested or tests are good quality. Coverage shows which code is executed and which is not.

**Guidelines:** Aim for high coverage of critical paths; 100% not always necessary; use coverage to find untested code; don't write tests just to increase coverage.

## Parameterized Tests

Same test logic, different data. Use when: same behavior with multiple inputs, edge cases sharing the same structure, boundary testing.

```javascript
// Jest / Vitest — test.each
test.each([
  [2, 3, 5],
  [-2, -3, -5],
  [0, 0, 0],
])('add(%i, %i) returns %i', (a, b, expected) => {
  expect(add(a, b)).toBe(expected);
});
```

```python
# pytest — @pytest.mark.parametrize
@pytest.mark.parametrize("a, b, expected", [
    (2, 3, 5),
    (-2, -3, -5),
    (0, 0, 0),
])
def test_add(a, b, expected):
    assert add(a, b) == expected
```

```go
// Go — table-driven tests
func TestAdd(t *testing.T) {
    tests := []struct {
        name     string
        a, b     int
        expected int
    }{
        {"positive", 2, 3, 5},
        {"negative", -2, -3, -5},
        {"zeros", 0, 0, 0},
    }
    for _, tt := range tests {
        t.Run(tt.name, func(t *testing.T) {
            if got := add(tt.a, tt.b); got != tt.expected {
                t.Errorf("add(%d, %d) = %d, want %d", tt.a, tt.b, got, tt.expected)
            }
        })
    }
}
```

> **See also:** For generating test cases from properties rather than explicit data, see the `property-based-testing` skill.

## Test Smells and How to Fix Them

| Smell | Symptom | Fix |
|-------|---------|-----|
| Test Does Too Much | Long test with many assertions | Split into multiple focused tests |
| Tests Are Brittle | Break with unrelated changes | Test behavior, not implementation details |
| Tests Are Slow | Test suite takes too long | Use test doubles, optimize setup, parallelize |
| Tests Are Unclear | Hard to understand what test does | Better naming, clear AAA structure |
| Tests Depend on Each Other | Fail when run in different order | Ensure test isolation, proper setup/teardown |
| Duplicate Setup Code | Same setup in many tests | Extract to fixtures, use test data builders |
| Assertion Roulette | Multiple assertions with no messages — unclear which condition broke | Add descriptive assertion messages or split into separate tests |
| Test Desert | Critical code paths have no tests | Use coverage tools; prioritize error paths and edge cases |
| The Liar | Test passes but doesn't verify behavior (asserts against setup data, not result) | Temporarily change expected value — if test still passes, assertion is meaningless |

## Resources

See `resources/` directory for:
- `aaa-pattern-template.md` - AAA test template
- `test-doubles-guide.md` - When to use each test double type
- `assertion-patterns.md` - Common assertion patterns by scenario
- `test-organization-examples.md` - Organization structure examples

## Relationship to Other Skills

- `tdd-red-phase` - Writing test structure
- `tdd-green-phase` - Understanding test requirements
- `tdd-refactor-phase` - Improving test quality
- `tdd-failure-recovery` - Understanding why tests fail
- `property-based-testing` - Generative test case strategies

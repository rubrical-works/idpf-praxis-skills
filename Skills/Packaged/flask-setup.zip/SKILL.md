---
name: flask-setup-for-beginners
description: Set up Python Flask development environment for beginners with step-by-step guidance, virtual environment creation, and troubleshooting
version: "1.0.1"
frameworkCompatibility: ">=0.60.0"
lastUpdated: "2026-03-17"
license: Complete terms in LICENSE.txt
category: platform
relevantTechStack: [flask, python, virtualenv, pip]
invocationMode: auto
copyright: "Rubrical Works (c) 2026"
---

# Flask Setup for Beginners

This Skill guides complete beginners through setting up a Flask development environment with detailed explanations and verification steps.

## When to Use This Skill

- User wants to build a Flask web application
- User is a beginner and needs Flask environment setup
- User asks "How do I set up Flask?" or "How do I start a Flask project?"
- Building a Python web API or Python web server

## Instructions for ASSISTANT

**CRITICAL OUTPUT FORMAT:**

When using this Skill's content, the ASSISTANT must format ALL technical instructions as **Claude Code copy/paste blocks**.

**DO NOT provide manual instructions like:**
- "Open File Explorer"
- "Navigate to folder"
- "Right-click"
- "Type in terminal"

**ALWAYS format as:**
```
TASK: Set up Flask project

STEP 1: Copy this entire code block (including this line)
STEP 2: Open Claude Code
STEP 3: Paste into Claude Code
STEP 4: Claude Code will execute and report results
STEP 5: Report back: What did Claude Code say?

---

[Instructions for Claude Code to execute:]

Navigate to project directory and create project folder:
cd [project-location]
mkdir [project-name]
cd [project-name]

[continue with commands...]

Report:
- What results did you see?
```

## Setup Knowledge

### STEP 3: Create Virtual Environment

```bash
python -m venv venv
```

Creates a special Python environment just for this project, preventing conflicts between different projects.

**Verify:** You should see a new `venv` folder in your project directory.

**Common issues:**
- "python: command not found" → Install Python from python.org; on Windows, check "Add Python to PATH" during installation
- "python3" instead of "python" → Try `python3 -m venv venv`

### STEP 4: Activate Virtual Environment

**Windows PowerShell:**
```bash
venv\Scripts\Activate.ps1
```

**Windows Command Prompt:**
```bash
venv\Scripts\activate.bat
```

**Mac/Linux:**
```bash
source venv/bin/activate
```

**Success indicator:** You'll see `(venv)` appear at the start of your terminal prompt.

**Common issues:**
- "Execution policy error" (Windows) → Run PowerShell as Administrator:
  ```bash
  Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
  ```

### STEP 5: Install Flask

```bash
pip install flask
```

Downloads Flask and its dependencies (Werkzeug, Jinja2, Click) into your virtual environment.

**Common issues:**
- "pip: command not found" → Virtual environment not activated (see Step 4)

### STEP 6: Create app.py File

**File location should be:**
```
my-project/
├── venv/           ← Virtual environment folder
└── app.py          ← Your main Flask file (create this)
```

**Don't create app.py inside the venv folder!**

### STEP 7: Verify Installation

```bash
python --version
pip list
python -c "import flask; print(flask.__version__)"
```

**Expected:** Python 3.8.x or higher; Flask visible in pip list; Flask version number printed.

## What Happens Next

After successful setup:
1. ASSISTANT will guide you through creating your first Flask route
2. You'll write "Hello World" application
3. You'll start the Flask development server
4. You'll see your first web page in a browser

## Troubleshooting Quick Reference

**Most common issues:**
1. **Forgot to activate virtual environment** → See Step 4
2. **Python not in PATH** → Reinstall Python with "Add to PATH" checked
3. **Wrong directory** → Use `cd` to navigate to project folder
4. **Permission errors** → Virtual environment not activated
5. **Port/firewall issues** → Will address when running server

See `resources/verification-checklist.md` for detailed troubleshooting steps.

**Remember:** Keep the terminal window with `(venv)` open while developing!

---
name: tdd-green-phase
description: Guide experienced developers through GREEN phase of TDD cycle - writing minimal implementation to pass failing tests
version: "1.0.0"
frameworkCompatibility: ">=0.60.0"
lastUpdated: "2026-03-17"
license: Complete terms in LICENSE.txt
category: testing
relevantTechStack: [tdd, jest, vitest, pytest, go, rust, rspec, testing]
invocationMode: auto
defaultSkill: true
copyright: "Rubrical Works (c) 2026"
---

# TDD GREEN Phase

## When to Use This Skill

- RED phase test has been verified as failing
- Proceeding autonomously from RED phase
- Implementing feature to pass test
- Moving from RED to GREEN in TDD cycle

## Prerequisites

- Completed RED phase with verified failing test
- Clear understanding of what test expects
- Implementation environment ready
- Claude Code available for code execution and testing

## GREEN Phase Objectives

**Write the minimum code to make the test pass.**

**Correct approach:** Implements exactly what test requires; no additional features beyond test scope; simplest solution that makes test green; avoids premature optimization.
**Incorrect approach:** Implements features not tested; over-engineers solution; adds "might need later" functionality; optimizes before necessary.

## GREEN Phase Workflow

### Step 1: Understand Test Requirements

Review the failing test to identify:
- What behavior is expected?
- What inputs does test provide?
- What output/result does test expect?
- What edge cases does this test cover?

**Key principle:** Test defines the contract. Implementation must fulfill contract, nothing more.

### Step 2: Plan Minimal Implementation

Identify: minimum logic needed, required data structures, necessary dependencies, expected return values/side effects.

Avoid planning: features not in test, abstractions not yet needed, optimizations not required, error handling not tested.

### Step 3: Implement to Pass Test

1. Locate or create the implementation file
2. Write the minimum code to make the test pass
3. Execute the test and verify it passes

### Step 4: Execute and Verify Success

**Verification checklist:**
- [ ] Test executed without errors
- [ ] Test passed (green)
- [ ] No other tests broke (if running full suite)
- [ ] Implementation is minimal and clear

### Step 5: Analyze Success

**If test passes:** → GREEN phase complete → Proceed autonomously to REFACTOR phase
**If test still fails:** → Implementation incomplete or incorrect → Revise implementation → Repeat Step 3
**If test passes but other tests fail:** → Implementation broke existing functionality → Revise to fix regressions → Re-run all tests

## GREEN Phase Best Practices

### Principle 1: YAGNI (You Aren't Gonna Need It)

**Good (minimal):** Implements exactly what test requires; hard-coded values acceptable if test passes; simple conditional logic; direct implementation.
**Poor (over-engineered):** Implements untested features "just in case"; complex abstractions for single use case; premature optimization; anticipatory design.

### Principle 2: Simplest Thing That Works

```
Test: Function should return sum of two numbers

WRONG (over-engineered): Generic calculation engine, configuration system, plugin architecture
RIGHT (minimal): Function takes two parameters, returns their sum
```

### Principle 3: Let Tests Drive Design

Test tells you: function signature needed, parameters required, return type expected, behavior specification. Implementation follows test exactly — no more, no less.

### Principle 4: Hard-Code First, Generalize Later

```
Test expects specific output? → Return that specific output (hard-coded) → Generalize in future tests
Test expects list with one item? → Return list with that one item → Handle multiple items when tested
Test checks single condition? → Implement that condition only → Add more conditions when tested
```

## Common GREEN Phase Mistakes

**Mistake 1: Over-Implementation** — Adding features not required by test. Solution: Implement ONLY what test requires; trust that future tests will drive future features.

**Mistake 2: Premature Abstraction** — Creating abstractions before they're needed. Solution: Wait for second or third use case; Rule of Three: abstract after third duplication.

**Mistake 3: Ignoring Test Failure Details** — Not reading what test actually expects. Solution: Read failure message carefully; understand exact expectation; implement precise requirement.

**Mistake 4: Breaking Existing Tests** — Making current test pass but breaking others. Solution: Run full test suite; ensure all tests remain green; fix regressions before proceeding.

## GREEN Phase Anti-Patterns

```
✗ WRONG: Test: User can log in → Implementation: Login + password reset + 2FA + OAuth
✓ CORRECT: Test: User can log in → Implementation: Basic login functionality only

✗ WRONG: Test: Function returns result → Implementation: Cached, memoized, async, optimized
✓ CORRECT: Test: Function returns result → Implementation: Straightforward synchronous function

✗ WRONG: Test fails → Copy random code from internet → Test passes
✓ CORRECT: Test fails → Understand requirement → Implement minimal solution
```

## Implementation Strategies

**Strategy 1: Fake It (Temporarily)** — Test expects result 5 → return 5. Next test expects different result → now implement real logic. Valid temporary approach, not final solution.

**Strategy 2: Obvious Implementation** — Solution is straightforward: `return a + b`. Clear, simple, complete.

**Strategy 3: Triangulation** — Multiple tests force generalization:
```
Test 1: add(2, 3) → return 5 (works)
Test 2: add(1, 4) → return 5 (still works)
Test 3: add(2, 2) → return 4 (now fails! must implement: return a + b)
```

## Integration with IDPF-Agile

GREEN phase follows RED in story implementation. When `/work` triggers TDD:
1. RED phase verified — test is failing
2. Implement minimal code to pass test
3. Run test and verify pass
4. Proceed to REFACTOR phase

The TDD cycle runs autonomously. The only user checkpoint is at story completion (In Review → Done).

## GREEN Phase Checklist

- [ ] Implementation code is complete and correct
- [ ] Target test now PASSES (green)
- [ ] Implementation is minimal (no over-engineering)
- [ ] No existing tests broke (full suite green)
- [ ] Code is understandable and clear
- [ ] Implementation matches test requirements exactly
- [ ] No untested features added

## Resources

See `resources/` directory for:
- `green-phase-checklist.md` - Quick reference checklist
- `minimal-implementation-guide.md` - How to identify minimum code
- `triangulation-examples.md` - When and how to use triangulation

## Relationship to Other Skills

- `tdd-red-phase` - Previous phase with failing test
- `tdd-refactor-phase` - Next phase after GREEN success
- `tdd-failure-recovery` - Handle unexpected GREEN phase failures
- `test-writing-patterns` - Understanding test requirements

---
name: ci-cd-pipeline-design
description: Guide developers through CI/CD pipeline design including architecture patterns, stage design, and security considerations
version: "1.0.0"
frameworkCompatibility: ">=0.60.0"
lastUpdated: "2026-03-17"
license: Complete terms in LICENSE.txt
category: devops
relevantTechStack: [github-actions, ci, cd, docker, kubernetes]
invocationMode: direct-only
copyright: "Rubrical Works (c) 2026"
---

# CI/CD Pipeline Design

This Skill guides developers through designing effective CI/CD pipelines including pipeline architecture, stage design, environment promotion strategies, and security considerations.

## When to Use This Skill

- Setting up CI/CD for a new project
- Optimizing existing pipeline performance
- Adding security scanning to pipelines
- Designing multi-environment deployment
- Choosing between CI/CD platforms

## CI/CD Fundamentals

### Continuous Integration (CI)
Automatically build and test code on every change.
- **Goals:** Detect integration issues early, maintain code quality, fast feedback
- **Key practices:** Frequent commits, automated builds and tests, feedback under 10 minutes

### Continuous Delivery (CD)
Automatically prepare releases for deployment.
- **Goals:** Always deployable main branch, consistent release process
- **Key practices:** Automated deployment to staging, manual approval for production, rollback capability

### Continuous Deployment
Automatically deploy every change to production.
- **Requirements:** High test coverage, feature flags, monitoring, fast rollback

## Pipeline Architecture

### Linear Pipeline
```
┌───────┐    ┌──────┐    ┌──────────┐    ┌────────┐
│ Build │ →  │ Test │ →  │ Security │ →  │ Deploy │
└───────┘    └──────┘    └──────────┘    └────────┘
```
Best for: Simple projects, single deployment target.

### Parallel Pipeline
```
              ┌─────────────┐
          ┌───│ Unit Tests  │───┐
          │   └─────────────┘   │
┌───────┐ │   ┌─────────────┐   │   ┌────────┐
│ Build │─┼───│ Lint/Format │───┼───│ Deploy │
└───────┘ │   └─────────────┘   │   └────────┘
          │   ┌─────────────┐   │
          └───│ SAST Scan   │───┘
              └─────────────┘
```
Best for: Faster feedback, independent quality gates.

### Multi-Environment Pipeline
```
┌───────┐    ┌──────┐    ┌─────────┐    ┌─────────┐    ┌────────────┐
│ Build │ →  │ Test │ →  │ Staging │ →  │ Approval│ →  │ Production │
└───────┘    └──────┘    └─────────┘    └─────────┘    └────────────┘
```
Best for: Production deployments, compliance requirements.

## Stage Design

### Security Stage Tools by Category
- SAST: SonarQube, Semgrep, CodeQL
- Dependencies: Dependabot, Snyk, OWASP Dependency-Check
- Secrets: GitLeaks, TruffleHog
- Containers: Trivy, Clair, Anchore

### Test Pyramid
```
        /\
       /E2E\      Few, slow, expensive
      /─────\
     / Int   \    Some, medium speed
    /─────────\
   /   Unit    \  Many, fast, cheap
  /─────────────\
```

## Environment Promotion

### Sequential Promotion
```
Dev → QA → Staging → Production
```

### Blue-Green Deployment
Deploy new version to Green; test; switch traffic to Green; keep Blue for rollback.

### Canary Deployment
Deploy to subset; monitor errors and performance; gradually increase traffic; full rollout or rollback.

### Rolling Deployment
Update instances one at a time; wait for health checks; continue until all updated.

## Platform-Specific Examples

### GitHub Actions

```yaml
name: CI/CD Pipeline

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Build
        run: npm ci && npm run build
      - name: Upload artifact
        uses: actions/upload-artifact@v4
        with:
          name: build
          path: dist/

  test:
    needs: build
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Run tests
        run: npm ci && npm test

  security:
    needs: build
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Run security scan
        uses: github/codeql-action/analyze@v2

  deploy-staging:
    needs: [test, security]
    runs-on: ubuntu-latest
    environment: staging
    steps:
      - name: Deploy to staging
        run: ./deploy.sh staging

  deploy-production:
    needs: deploy-staging
    runs-on: ubuntu-latest
    environment: production
    steps:
      - name: Deploy to production
        run: ./deploy.sh production
```

### GitLab CI

```yaml
stages:
  - build
  - test
  - security
  - deploy

build:
  stage: build
  script:
    - npm ci
    - npm run build
  artifacts:
    paths:
      - dist/

test:
  stage: test
  script:
    - npm ci
    - npm test

sast:
  stage: security
  template: Security/SAST.gitlab-ci.yml

deploy_staging:
  stage: deploy
  script:
    - ./deploy.sh staging
  environment:
    name: staging
  only:
    - main

deploy_production:
  stage: deploy
  script:
    - ./deploy.sh production
  environment:
    name: production
  when: manual
  only:
    - main
```

### Jenkins (Declarative)

```groovy
pipeline {
    agent any
    stages {
        stage('Build') {
            steps {
                sh 'npm ci'
                sh 'npm run build'
            }
        }
        stage('Test') {
            parallel {
                stage('Unit Tests') { steps { sh 'npm test' } }
                stage('Integration Tests') { steps { sh 'npm run test:integration' } }
            }
        }
        stage('Security') { steps { sh 'npm audit' } }
        stage('Deploy Staging') {
            when { branch 'main' }
            steps { sh './deploy.sh staging' }
        }
        stage('Deploy Production') {
            when { branch 'main' }
            input { message "Deploy to production?" }
            steps { sh './deploy.sh production' }
        }
    }
}
```

## Security Considerations

### Secrets Management
- Never hardcode secrets; use environment variables and secret management services
- Rotate secrets regularly; audit secret access

```yaml
steps:
  - name: Deploy
    env:
      API_KEY: ${{ secrets.API_KEY }}
    run: ./deploy.sh
```

### SAST Integration
```yaml
security_scan:
  steps:
    - name: Run SAST
      run: semgrep --config=auto src/
    - name: Check results
      run: |
        if grep -q "CRITICAL\|HIGH" results.txt; then
          exit 1
        fi
```

### Supply Chain Security
```yaml
dependencies:
  steps:
    - name: Check dependencies
      run: npm audit --audit-level=high
    - name: SBOM generation
      run: syft packages . -o spdx-json > sbom.json
```

## GitHub API Best Practices

### Authentication Strategy
- Use fine-scoped PATs for specific permissions; GitHub Apps for org-level automation
- Reuse tokens across test runs; avoid rapidly creating/deleting tokens

### Rate Limiting
```yaml
retry:
  max_attempts: 3
  initial_interval: 1s
  multiplier: 2
  randomization_factor: 0.5  # Adds jitter
```
- Monitor rate limit headers (`X-RateLimit-Remaining`)
- Cache API responses where appropriate

### Workflow Triggers
```yaml
# Prevent concurrent runs on same branch
concurrency:
  group: ${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: true
```

### Abuse Detection Patterns
Patterns that trigger temporary lockouts: high volume auth attempts, rapid workflow creation/deletion, excessive API calls, concurrent operations without throttling.
**Prevention:** Fine-scoped PATs, request throttling, delays between bulk operations.

## Pipeline Best Practices

1. **Fast Feedback** — Keep CI under 10 minutes; run fast tests first; parallelize; cache dependencies
2. **Reliable Pipelines** — Make builds reproducible; pin dependency versions; implement retry logic
3. **Clear Visibility** — Good pipeline naming, meaningful error messages, notifications on failure
4. **Security First** — Scan early and often; block on security failures; minimal permissions
5. **Environment Parity** — Infrastructure as code; consistent deployment process

## Resources

See `resources/` directory for:
- `architecture-patterns.md` - Pipeline architecture patterns
- `stage-design.md` - Detailed stage design guidance
- `platform-examples.md` - Platform-specific configurations
- `security-checklist.md` - Security considerations checklist

## Relationship to Other Skills

- `api-versioning` - API deployment strategies
- `migration-patterns` - Database deployment considerations

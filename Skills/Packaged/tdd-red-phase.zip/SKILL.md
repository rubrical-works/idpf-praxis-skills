---
name: tdd-red-phase
description: Guide experienced developers through RED phase of TDD cycle - writing failing tests and verifying expected failures
version: "1.0.0"
frameworkCompatibility: ">=0.60.0"
lastUpdated: "2026-03-17"
license: Complete terms in LICENSE.txt
category: testing
relevantTechStack: [tdd, jest, vitest, pytest, go, rust, rspec, testing]
invocationMode: auto
defaultSkill: true
copyright: "Rubrical Works (c) 2026"
---

# TDD RED Phase

## When to Use This Skill

- Starting implementation of a new feature or behavior
- User triggers `work #N` in IDPF-Agile framework
- Beginning a new TDD iteration
- User needs guidance on writing a failing test

## Prerequisites

- Working development environment with test framework configured
- Clear understanding of the behavior to be tested
- Familiarity with TDD principles
- Claude Code available for test execution

## RED Phase Objectives

**Write a test that fails for the right reason.**

**Correct failure:** Test fails because feature doesn't exist yet; failure message clearly indicates what's missing.
**Incorrect failure:** Test fails due to syntax error, missing imports, incorrect test setup, or passes unexpectedly (test is invalid).

## RED Phase Workflow

### Step 1: Identify Testable Behavior

Focus on smallest testable behavior — one test case covering one behavior.

**Good behavior identification:**
```
✓ "Function returns sum of two numbers"
✓ "GET /users returns 200 status"
✓ "Invalid email shows validation error"
✓ "User can delete their own posts"
```

**Poor behavior identification:**
```
✗ "User management works" (too broad)
✗ "Fix the bug" (not a behavior)
✗ "Improve performance" (not testable as pass/fail)
```

### Step 2: Write the Failing Test

**Test structure (framework-agnostic):**
```
1. ARRANGE: Set up test data and preconditions
2. ACT: Execute the behavior being tested
3. ASSERT: Verify the expected outcome
```

**Framework-specific test syntax:**

```javascript
// Jest / Vitest
describe('featureName', () => {
  it('should behave as expected', () => {
    // Arrange → Act → Assert
  });
});
```

```python
# pytest
def test_feature_name_expected_behavior():
    # Arrange → Act → Assert
    pass
```

```go
// Go testing
func TestFeatureName_ExpectedBehavior(t *testing.T) {
    // Arrange → Act → Assert
}
```

```rust
// Rust
#[test]
fn feature_name_expected_behavior() {
    // Arrange → Act → Assert
}
```

```ruby
# RSpec
describe 'FeatureName' do
  it 'behaves as expected' do
    # Arrange → Act → Assert
  end
end
```

### Step 3: Execute and Verify Failure

**Verification checklist:**
- [ ] Test executed without syntax errors
- [ ] Test failed (not passed)
- [ ] Failure message indicates missing implementation
- [ ] Failure message is clear and understandable

### Step 4: Analyze Failure

**If test fails as expected:** → RED phase complete → Proceed to GREEN phase
**If test passes unexpectedly:** → Test is invalid → Revise test to target unimplemented behavior → Repeat Step 2
**If test errors instead of fails:** → Test has bugs (syntax, imports, setup) → Fix test code → Repeat Step 2

## RED Phase Best Practices

**Write Minimal Tests:** One specific behavior, simplest possible test data, single assertion (or closely related assertions).

**Use Clear Test Names:**
```
test_[feature]_[scenario]_[expected_result]

Examples:
- test_add_function_with_positive_numbers_returns_sum
- test_get_users_when_authenticated_returns_200
- test_create_post_with_invalid_data_returns_validation_error
```

**Write Descriptive Assertions:** Specific and precise, include helpful failure messages, test observable behavior not implementation.

## Common RED Phase Mistakes

**Mistake 1: Test Passes Immediately** — Wrote test for already-implemented feature. Solution: Verify feature doesn't exist; if exists, delete implementation first; re-run to confirm failure.

**Mistake 2: Test Has Syntax Errors** — Test won't run. Solution: Fix syntax errors, ensure proper imports, verify test framework setup.

**Mistake 3: Test Too Broad** — Tests multiple behaviors at once. Solution: Split into multiple tests, one test per behavior.

**Mistake 4: Unclear Failure Message** — Doesn't explain what's missing. Solution: Add descriptive assertion messages, use clear variable names, test one thing at a time.

## RED Phase Anti-Patterns

```
✗ WRONG (write code first):
1. Write code → 2. Write test to verify code → 3. Test passes immediately

✓ CORRECT (TDD):
1. Write failing test → 2. Write code to pass test → 3. Test now passes

✗ WRONG (skip verification):
1. Write test → 2. Assume it will fail → 3. Move to GREEN phase

✓ CORRECT:
1. Write test → 2. RUN test and VERIFY it fails → 3. Confirm failure reason → 4. Move to GREEN phase

✗ WRONG (tolerate errors):
Test throws exception → "I'll fix it in GREEN phase"

✓ CORRECT:
Test throws exception → "Fix test now so it fails cleanly"
```

## Integration with IDPF-Agile

RED phase is the first step of story implementation. When `/work` triggers TDD:
1. Break story into testable behaviors
2. Write and run RED phase test
3. Verify failure
4. Proceed to GREEN phase

The TDD cycle runs autonomously. The only user checkpoint is at story completion (In Review → Done).

## RED Phase Checklist

- [ ] Test code is complete and syntactically correct
- [ ] Test executes without errors
- [ ] Test FAILS (does not pass)
- [ ] Failure message clearly indicates missing implementation
- [ ] Test name clearly describes behavior being tested
- [ ] Test is focused on single behavior
- [ ] Test uses minimal, clear test data

## Resources

See `resources/` directory for:
- `red-phase-checklist.md` - Quick reference checklist
- `test-structure-patterns.md` - Common test structure patterns
- `failure-verification-guide.md` - How to verify test failures correctly

## Relationship to Other Skills

- `tdd-green-phase` - Next phase after RED phase success
- `test-writing-patterns` - Detailed test structure guidance
- `tdd-failure-recovery` - Handle unexpected RED phase results

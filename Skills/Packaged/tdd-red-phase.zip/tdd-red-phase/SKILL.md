---
name: tdd-red-phase
description: Guide experienced developers through RED phase of TDD cycle - writing failing tests and verifying expected failures
version: "1.0.0"
frameworkCompatibility: ">=0.60.0"
lastUpdated: "2026-03-17"
license: Complete terms in LICENSE.txt
category: testing
relevantTechStack: [tdd, jest, vitest, pytest, go, rust, rspec, testing]
invocationMode: auto
defaultSkill: true
copyright: "Rubrical Works (c) 2026"
---

# TDD RED Phase

This Skill guides experienced developers through the RED phase of the Test-Driven Development cycle: writing failing tests and verifying expected failures.

## When to Use This Skill

Invoke this Skill when:
- Starting implementation of a new feature or behavior
- User triggers `work #N` in IDPF-Agile framework
- Beginning a new TDD iteration
- User needs guidance on writing a failing test

## Prerequisites

- Working development environment with test framework configured
- Clear understanding of the behavior to be tested
- Familiarity with TDD principles
- Claude Code available for test execution

## RED Phase Objectives

The RED phase has one critical goal: **Write a test that fails for the right reason.**

### What "Right Reason" Means

**✓ Correct failure:**
- Test fails because feature doesn't exist yet
- Test fails because behavior not implemented
- Failure message clearly indicates what's missing

**✗ Incorrect failure:**
- Test fails due to syntax error
- Test fails due to missing imports
- Test fails due to incorrect test setup
- Test passes unexpectedly (test is invalid)

## RED Phase Workflow

### Step 1: Identify Testable Behavior

**From IDPF-Agile:**
- "Decompose story into testable behaviors"
- Focus on smallest testable behavior (typically one test case covering one behavior)

**Key principle:** One test per behavior, one behavior per test.

**Good behavior identification:**
```
✓ "Function returns sum of two numbers"
✓ "GET /users returns 200 status"
✓ "Invalid email shows validation error"
✓ "User can delete their own posts"
```

**Poor behavior identification:**
```
✗ "User management works" (too broad)
✗ "Fix the bug" (not a behavior)
✗ "Improve performance" (not testable as pass/fail)
```

### Step 2: Write the Failing Test

**Test structure (framework-agnostic):**

```
1. ARRANGE: Set up test data and preconditions
2. ACT: Execute the behavior being tested
3. ASSERT: Verify the expected outcome
```

**Write the test directly:**

1. Identify the test file (create if needed)
2. Write the test with AAA structure (Arrange-Act-Assert)
3. Include all imports and setup
4. Execute the test and verify it fails

**Framework-specific test syntax:**

```javascript
// Jest / Vitest
describe('featureName', () => {
  it('should behave as expected', () => {
    // Arrange → Act → Assert
  });
});
```

```python
# pytest
def test_feature_name_expected_behavior():
    # Arrange → Act → Assert
    pass
```

```go
// Go testing
func TestFeatureName_ExpectedBehavior(t *testing.T) {
    // Arrange → Act → Assert
}
```

```rust
// Rust
#[test]
fn feature_name_expected_behavior() {
    // Arrange → Act → Assert
}
```

```ruby
# RSpec
describe 'FeatureName' do
  it 'behaves as expected' do
    # Arrange → Act → Assert
  end
end
```

### Step 3: Execute and Verify Failure

Execute the test directly and verify it FAILS (not passes, not errors).

**Verification checklist:**
- [ ] Test executed without syntax errors
- [ ] Test failed (not passed)
- [ ] Failure message indicates missing implementation
- [ ] Failure message is clear and understandable

### Step 4: Analyze Failure

**If test fails as expected:**
→ RED phase complete
→ Proceed to GREEN phase

**If test passes unexpectedly:**
→ Test is invalid (probably testing wrong thing)
→ Revise test to target unimplemented behavior
→ Repeat Step 2

**If test errors instead of fails:**
→ Test has bugs (syntax, imports, setup)
→ Fix test code
→ Repeat Step 2

## RED Phase Best Practices

### Write Minimal Tests

**Good (minimal):**
```
Test verifies one specific behavior
Uses simplest possible test data
Single assertion (or closely related assertions)
```

**Poor (excessive):**
```
Test verifies multiple unrelated behaviors
Complex test data setup
Multiple unrelated assertions
```

### Use Clear Test Names

**Framework-agnostic naming conventions:**

```
test_[feature]_[scenario]_[expected_result]

Examples:
- test_add_function_with_positive_numbers_returns_sum
- test_get_users_when_authenticated_returns_200
- test_create_post_with_invalid_data_returns_validation_error
```

### Write Descriptive Assertions

**Good assertions:**
```
Assert with clear comparison
Include helpful failure messages
Test observable behavior, not implementation
```

**Poor assertions:**
```
Assert True without context
No failure messages
Test internal state instead of behavior
```

## Common RED Phase Mistakes

### Mistake 1: Test Passes Immediately

**Problem:** Wrote test for already-implemented feature

**Solution:**
- Verify feature doesn't exist yet
- If exists, delete implementation first
- Re-run test to confirm failure

### Mistake 2: Test Has Syntax Errors

**Problem:** Test won't run due to code errors

**Solution:**
- Fix syntax errors
- Ensure proper imports
- Verify test framework setup
- Run test again

### Mistake 3: Test Too Broad

**Problem:** Test checks multiple behaviors at once

**Solution:**
- Split into multiple tests
- One test per behavior
- Keep tests focused and simple

### Mistake 4: Unclear Failure Message

**Problem:** When test fails, message doesn't explain what's missing

**Solution:**
- Add descriptive assertion messages
- Use clear variable names
- Test one thing at a time

## RED Phase Anti-Patterns

### Anti-Pattern 1: Writing Implementation First

```
✗ WRONG:
1. Write code
2. Write test to verify code
3. Test passes immediately

✓ CORRECT (TDD):
1. Write failing test
2. Write code to pass test
3. Test now passes
```

### Anti-Pattern 2: Skipping Failure Verification

```
✗ WRONG:
1. Write test
2. Assume it will fail
3. Move to GREEN phase

✓ CORRECT:
1. Write test
2. RUN test and VERIFY it fails
3. Confirm failure reason is correct
4. Then move to GREEN phase
```

### Anti-Pattern 3: Tolerating Test Errors

```
✗ WRONG:
Test throws exception → "I'll fix it in GREEN phase"

✓ CORRECT:
Test throws exception → "Fix test now so it fails cleanly"
```

## Integration with IDPF-Agile

RED phase is the first step of story implementation. When `/work` triggers TDD:

1. Break story into testable behaviors
2. Write and run RED phase test
3. Verify failure
4. Proceed to GREEN phase

The TDD cycle runs autonomously. The only user checkpoint is at story completion (In Review → Done).

## RED Phase Checklist

Before proceeding to GREEN phase, verify:

- [ ] Test code is complete and syntactically correct
- [ ] Test executes without errors
- [ ] Test FAILS (does not pass)
- [ ] Failure message clearly indicates missing implementation
- [ ] Test name clearly describes behavior being tested
- [ ] Test is focused on single behavior
- [ ] Test uses minimal, clear test data

## Resources

See `resources/` directory for:
- `red-phase-checklist.md` - Quick reference checklist
- `test-structure-patterns.md` - Common test structure patterns
- `failure-verification-guide.md` - How to verify test failures correctly

## Relationship to Other Skills

**Flows to:**
- `tdd-green-phase` - Next phase after RED phase success

**Related skills:**
- `test-writing-patterns` - Detailed test structure guidance
- `tdd-failure-recovery` - Handle unexpected RED phase results

**Independent from:**
- `beginner-testing` - This skill assumes TDD experience

## Expected Outcome

After successful RED phase:
- One failing test exists
- Failure is verified and understood
- Test clearly defines expected behavior
- Ready to implement minimum code to pass test (GREEN phase)
- Autonomous progression to GREEN phase (no user command needed)

**End of TDD RED Phase Skill**
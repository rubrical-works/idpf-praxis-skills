---
name: sinatra-setup-for-beginners
description: Set up Ruby Sinatra development environment for beginners with step-by-step guidance, Bundler setup, and troubleshooting
version: "1.0.0"
frameworkCompatibility: ">=0.60.0"
lastUpdated: "2026-03-17"
license: Complete terms in LICENSE.txt
category: platform
relevantTechStack: [sinatra, ruby, bundler, gem]
invocationMode: auto
copyright: "Rubrical Works (c) 2026"
---

# Sinatra Setup for Beginners

## When to Use This Skill

- User wants to build a Sinatra web application
- User is a beginner and needs Sinatra environment setup
- User asks "How do I set up Sinatra?" or "How do I start a Sinatra project?"
- Project type is determined to be web application using Sinatra/Ruby
- Building a Ruby web API or Ruby web server

## Instructions for ASSISTANT

**CRITICAL OUTPUT FORMAT:**

When using this Skill's content, the ASSISTANT must format ALL technical instructions as **Claude Code copy/paste blocks**.

**DO NOT provide manual instructions like:**
- "Open File Explorer"
- "Navigate to folder"
- "Right-click"

**ALWAYS format as:**
```
TASK: Set up Sinatra project

STEP 1: Copy this entire code block (including this line)
STEP 2: Open Claude Code
STEP 3: Paste into Claude Code
STEP 4: Claude Code will execute and report results
STEP 5: Report back: What did Claude Code say?

---

[Instructions for Claude Code to execute:]

Navigate to project directory:
cd [project-location]

Create project folder:
mkdir [project-name]
cd [project-name]

Verify Ruby installed:
ruby --version

[continue with commands...]

Report:
- What results did you see?
```

## Setup Knowledge

### STEP 1: Verify Ruby

```bash
ruby --version
```

**Expected output:** `ruby 3.0.0` or higher

**If Ruby is NOT installed:**

**Windows:** Download RubyInstaller from https://rubyinstaller.org/, choose "Ruby+Devkit 3.2.X", run installer with default settings, check "Add Ruby to PATH", restart terminal.

**Mac:**
```bash
brew install ruby
```

**Linux (Ubuntu/Debian):**
```bash
sudo apt-get update
sudo apt-get install ruby-full
```

### STEP 4: Install Bundler

```bash
gem install bundler
bundler --version
```

**Expected:** `Bundler version 2.X.X`

**Common issues:**
- "Permission denied" → Use `sudo gem install bundler` (Mac/Linux)
- "gem: command not found" → Ruby not installed properly

### STEP 5: Create Gemfile

File must be named exactly `Gemfile` (capital G, no extension) in project root.

```ruby
source 'https://rubygems.org'

gem 'sinatra'
```

### STEP 6: Install Sinatra and Dependencies

```bash
bundle install
```

What gets installed: Sinatra, Rack, Rack Protection, Tilt.

After installation:
```
my-project/
├── Gemfile
└── Gemfile.lock
```

**Common issues:**
- "Could not locate Gemfile" → Make sure you're in project directory
- "Permission denied" → Use `bundle install --path vendor/bundle`

### STEP 7: Create app.rb

```
my-project/
├── Gemfile
├── Gemfile.lock
└── app.rb
```

### STEP 8: Verify Installation

```bash
ruby --version          # ruby 3.0.0 or higher
bundle --version        # Bundler version 2.X.X
bundle list             # Should include sinatra, rack, etc.
ruby -e "require 'sinatra'; puts 'Sinatra works!'"
```

**All checks pass?** You're ready to start coding!

## Project Structure Summary

```
my-project/
├── Gemfile           ← Gem dependencies
├── Gemfile.lock      ← Version lock (bundle created)
└── app.rb            ← Your code

# Later you'll add:
├── views/
│   └── index.erb
└── public/
    └── style.css
```

## Troubleshooting Quick Reference

See `resources/verification-checklist.md` for detailed troubleshooting steps.

1. **Ruby not installed** → Follow Step 1 installation instructions
2. **Gemfile in wrong location** → Must be in project root
3. **Permission errors** → Use `bundle install --path vendor/bundle`
4. **Network/firewall issues** → Check internet connection
5. **Old Ruby version** → Update Ruby to 3.0+

**Remember:** Run `bundle exec ruby app.rb` to start your Sinatra app (bundle exec ensures correct gem versions)

/**
 * Unit tests for test-coverage-audit.js
 *
 * Run with: node tests/test-coverage-audit.test.js
 * No external dependencies — uses node:assert and a tiny test harness.
 */

'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const os = require('os');

const audit = require('../scripts/test-coverage-audit.js');

const tests = [];
function test(name, fn) { tests.push({ name, fn }); }

// ---------- arg parsing ----------
test('parseArgs: --since-commit value', () => {
  const args = audit.parseArgs(['--since-commit', 'abc123']);
  assert.strictEqual(args.sinceCommit, 'abc123');
});
test('parseArgs: --since-commit=value', () => {
  const args = audit.parseArgs(['--since-commit=abc']);
  assert.strictEqual(args.sinceCommit, 'abc');
});
test('parseArgs: --config-only', () => {
  assert.strictEqual(audit.parseArgs(['--config-only']).configOnly, true);
});

// ---------- glob ----------
test('globToRegex: * matches segment', () => {
  assert.ok(audit.globToRegex('*.ts').test('foo.ts'));
  assert.ok(!audit.globToRegex('*.ts').test('a/foo.ts'));
});
test('globToRegex: ** crosses segments', () => {
  assert.ok(audit.globToRegex('**/foo.ts').test('a/b/foo.ts'));
  assert.ok(audit.globToRegex('**/foo.ts').test('foo.ts'));
});
test('matchAny: empty patterns', () => {
  assert.strictEqual(audit.matchAny('a.ts', []), false);
  assert.strictEqual(audit.matchAny('a.ts', null), false);
});

// ---------- language detection ----------
const LANGS = {
  typescript: { sourceExtensions: ['.ts'], testPatterns: ['{dir}/{stem}.test.ts'] },
  python: { sourceExtensions: ['.py'], testPatterns: ['{dir}/test_{stem}.py'], excludePatterns: ['**/__init__.py'] }
};
test('detectLanguage: typescript', () => {
  const r = audit.detectLanguage('src/foo.ts', LANGS);
  assert.strictEqual(r.name, 'typescript');
});
test('detectLanguage: excludes __init__.py', () => {
  assert.strictEqual(audit.detectLanguage('pkg/__init__.py', LANGS), null);
});
test('detectLanguage: unknown extension', () => {
  assert.strictEqual(audit.detectLanguage('foo.xyz', LANGS), null);
});

// ---------- {stem} / {dir} substitution ----------
test('expandTestPatterns: substitutes stem and dir', () => {
  const r = audit.expandTestPatterns('src/lib/foo.ts', ['{dir}/{stem}.test.ts', '{dir}/__tests__/{stem}.ts']);
  assert.deepStrictEqual(r, ['src/lib/foo.test.ts', 'src/lib/__tests__/foo.ts']);
});
test('expandTestPatterns: empty dir collapses leading slash', () => {
  const r = audit.expandTestPatterns('foo.ts', ['{dir}/{stem}.test.ts']);
  assert.deepStrictEqual(r, ['foo.test.ts']);
});

// ---------- override merging ----------
test('mergeConfig: no override returns conventions', () => {
  const conv = { languages: { ts: LANGS.typescript }, ignoredSourcePatterns: ['x'] };
  const merged = audit.mergeConfig(conv, null);
  assert.deepStrictEqual(Object.keys(merged.languages), ['ts']);
  assert.deepStrictEqual(merged.ignoredSourcePatterns, ['x']);
});
test('mergeConfig: additionalLanguages added', () => {
  const conv = { languages: { ts: LANGS.typescript } };
  const merged = audit.mergeConfig(conv, {
    additionalLanguages: { mydsl: { sourceExtensions: ['.mydsl'], testPatterns: ['spec/{stem}.spec.mydsl'] } }
  });
  assert.deepStrictEqual(Object.keys(merged.languages).sort(), ['mydsl', 'ts']);
});
test('mergeConfig: ignoredSourcePatterns concatenated', () => {
  const conv = { languages: { ts: LANGS.typescript }, ignoredSourcePatterns: ['a'] };
  const merged = audit.mergeConfig(conv, { ignoredSourcePatterns: ['b'] });
  assert.deepStrictEqual(merged.ignoredSourcePatterns, ['a', 'b']);
});
test('mergeConfig: minTestCoverageRatio applied', () => {
  const merged = audit.mergeConfig({ languages: {} }, { minTestCoverageRatio: 0.8 });
  assert.strictEqual(merged.minTestCoverageRatio, 0.8);
});

// ---------- inline tests (Rust) ----------
test('hasInlineTests: detects #[cfg(test)]', () => {
  const tmp = path.join(os.tmpdir(), `audit-${Date.now()}.rs`);
  fs.writeFileSync(tmp, 'pub fn foo() {}\n#[cfg(test)]\nmod tests {\n  #[test] fn t() {}\n}\n');
  assert.strictEqual(audit.hasInlineTests(tmp), true);
  fs.unlinkSync(tmp);
});
test('hasInlineTests: returns false for plain file', () => {
  const tmp = path.join(os.tmpdir(), `audit-plain-${Date.now()}.rs`);
  fs.writeFileSync(tmp, 'pub fn foo() {}\n');
  assert.strictEqual(audit.hasInlineTests(tmp), false);
  fs.unlinkSync(tmp);
});
test('hasInlineTests: missing file returns false', () => {
  assert.strictEqual(audit.hasInlineTests('/nonexistent/path.rs'), false);
});

// ---------- schema validation ----------
const SCHEMA = JSON.parse(fs.readFileSync(audit._paths.SCHEMA_PATH, 'utf8'));

test('validateSchema: valid fixture passes', () => {
  const data = JSON.parse(fs.readFileSync(path.join(__dirname, 'fixtures/valid-conventions.json'), 'utf8'));
  const errors = audit.validateSchema(SCHEMA, data);
  assert.deepStrictEqual(errors, []);
});
test('validateSchema: invalid fixture fails', () => {
  const data = JSON.parse(fs.readFileSync(path.join(__dirname, 'fixtures/invalid-conventions.json'), 'utf8'));
  const errors = audit.validateSchema(SCHEMA, data);
  assert.ok(errors.length > 0, 'expected schema errors, got none');
});
test('validateSchema: bundled conventions pass', () => {
  const data = JSON.parse(fs.readFileSync(audit._paths.CONVENTIONS_PATH, 'utf8'));
  const errors = audit.validateSchema(SCHEMA, data);
  assert.deepStrictEqual(errors, [], 'bundled conventions should validate cleanly');
});
test('validateSchema: missing languages field fails', () => {
  const errors = audit.validateSchema(SCHEMA, { _meta: { version: 1 } });
  assert.ok(errors.some((e) => /languages/.test(e)));
});

// ---------- runner ----------
let passed = 0;
let failed = 0;
const failures = [];
for (const t of tests) {
  try {
    t.fn();
    passed++;
  } catch (e) {
    failed++;
    failures.push({ name: t.name, error: e.message });
  }
}

console.log(`\n${passed} passed, ${failed} failed (${tests.length} total)`);
if (failed > 0) {
  for (const f of failures) console.log(`  FAIL ${f.name}\n    ${f.error}`);
  process.exit(1);
}

---
name: code-path-discovery
description: Scan TypeScript/JavaScript source files for behavioral paths and return candidates in 6-category format for /paths turn-based discovery
version: "1.0.0"
frameworkCompatibility: ">=0.60.0"
lastUpdated: "2026-03-17"
license: Complete terms in LICENSE.txt
category: analysis
relevantTechStack: [javascript, typescript]
invocationMode: manual
defaultSkill: false
copyright: "Rubrical Works (c) 2026"
---

# Code Path Discovery Skill

## Purpose

Scans TypeScript/JavaScript source code to detect behavioral patterns and map them to the 6-category path format used by `/paths`. Returns candidate scenarios as `{ shortLabel, description }` objects per category for turn-based collaborative discovery.

## When to Invoke

- **`/paths --from-code [path]`** — called by `/paths` Step 3b when `--from-code` flag is present
- Manual code analysis of unfamiliar codebases

## Parameters

| Parameter | Required | Type | Description |
|-----------|----------|------|-------------|
| `path` | Yes | string | Path to source directory to scan |
| `issueTitle` | Yes | string | Issue title for context |
| `issueBody` | No | string | Issue body for additional context |

## How to Use

1. Receive `path`, `issueTitle`, `issueBody` from `/paths` Step 3b
2. Load skill instructions from `resources/skill-instructions.md`
3. Follow scanning and mapping workflow in skill instructions
4. Return results as structured output for `/paths` Step 5

## Output Format

```json
{
  "nominalPath": [
    { "shortLabel": "User login flow", "description": "POST /login validates credentials and returns JWT token" }
  ],
  "alternativePaths": [
    { "shortLabel": "OAuth redirect", "description": "GET /auth/callback handles third-party authentication" }
  ],
  "exceptionPaths": [
    { "shortLabel": "Database connection error", "description": "catch block in db.connect() returns 503 Service Unavailable" }
  ],
  "edgeCases": [
    { "shortLabel": "Empty request body", "description": "Guard clause returns 400 when req.body is null/undefined" }
  ],
  "cornerCases": [
    { "shortLabel": "Concurrent session limit", "description": "Auth guard + session count check reject login when max sessions reached" }
  ],
  "negativeTestScenarios": [
    { "shortLabel": "Invalid token format", "description": "JWT validation middleware rejects malformed tokens with 401" }
  ]
}
```

Each `shortLabel` and `description` maps directly to `/paths` Step 5a `AskUserQuestion` `options[].label` and `options[].description`.

## Resources

- [Skill Instructions](resources/skill-instructions.md) — Pattern scanning rules and category mapping logic

## Related

- **`/paths` command** — Primary consumer of this skill's output
- **anti-pattern-analysis skill** — Complementary code analysis (quality, not behavioral paths)

## Known Limitations

Validated against `.claude/scripts/shared/` (36 JavaScript files, CLI utility scripts).

**False positives observed:**
- Guard clause detection (`if (!x)`) may match control flow that isn't a boundary guard. User validation in `/paths` Step 5b mitigates this.
- `module.exports` as nominal path — marks API surface in utility libs, not user-facing flow.
- Catch blocks in utility code — generic error wrapping may not be meaningful exception paths.

**Not detected:** Implicit callback error flows, promise chain errors without `.catch()`, configuration-driven behavior.

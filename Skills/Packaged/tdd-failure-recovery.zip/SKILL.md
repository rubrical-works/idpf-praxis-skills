---
name: tdd-failure-recovery
description: Guide experienced developers through TDD failure scenarios and recovery procedures when tests behave unexpectedly
version: "1.0.0"
frameworkCompatibility: ">=0.60.0"
lastUpdated: "2026-03-17"
license: Complete terms in LICENSE.txt
category: testing
relevantTechStack: [tdd, jest, vitest, pytest, go, rust, rspec, testing]
invocationMode: auto
defaultSkill: true
copyright: "Rubrical Works (c) 2026"
---

# TDD Failure Recovery

## When to Use This Skill

- RED phase test passes unexpectedly (should fail)
- GREEN phase test still fails (should pass)
- REFACTOR phase breaks tests (should stay green)
- Tests behave unpredictably or inconsistently
- Need to rollback to previous working state
- Need diagnostic guidance for test failures

## Prerequisites

- Understanding of expected TDD cycle behavior
- Knowledge of current TDD phase (RED/GREEN/REFACTOR)
- Test execution capability via Claude Code
- Version control or ability to undo changes

## Failure Scenarios and Recovery

### Scenario 1: RED Phase Test Passes Unexpectedly

**Expected:** Test should FAIL because feature not implemented
**Actual:** Test PASSES immediately

> "RED phase test passes unexpectedly: The test is invalid — revise the test"

**Possible causes:**
1. Feature already exists (code from previous iteration, similar feature implemented earlier)
2. Test is too permissive (assertion too broad, testing wrong thing, mock returns success by default)
3. Test setup incorrect (not exercising the code, bypassing actual implementation)

**Recovery Steps:**
1. Add intentional failure to test; confirm test can fail; remove intentional failure
2. Search codebase for feature; if found: delete implementation OR write test for different behavior
3. Review test logic — is assertion correct? Is test calling actual implementation?
4. Revise test; execute and verify it now fails as expected
5. Proceed to GREEN phase

### Scenario 2: GREEN Phase Test Still Fails

**Expected:** Implementation should make test PASS
**Actual:** Test still FAILS after implementation

> "GREEN phase test fails: Implementation is incomplete — revise the code"

**Possible causes:**
1. Implementation incomplete (missing edge case, incorrect logic, wrong return value)
2. Implementation has bugs (syntax errors, logic errors, type mismatches)
3. Test expectations misunderstood (implemented wrong behavior, partial implementation)
4. Environmental issues (dependencies not available, database/file system, configuration)

**Recovery Steps:**
1. Read failure message carefully — what does test expect vs what implementation provided?
2. Verify implementation executes without errors and matches test requirements
3. Re-read test assertions; understand exact expectations and verify test data
4. Write corrected implementation; execute and verify it now passes
5. Run full test suite — ensure no regressions
6. Proceed to REFACTOR phase

### Scenario 3: REFACTOR Phase Breaks Tests

**Expected:** Refactoring should keep all tests GREEN
**Actual:** One or more tests FAIL after refactoring

> "Refactoring breaks tests: Roll back refactoring; tests must stay green"

**Possible causes:**
1. Behavioral change introduced (refactoring accidentally changed logic, side effects changed)
2. Breaking change in API (function signature changed, return type modified)
3. Incomplete refactoring (updated some call sites, missed others)
4. Test dependency on implementation (test was coupled to specific implementation)

**Recovery Steps:**

**Step 1: IMMEDIATE ROLLBACK**
```
TESTS MUST STAY GREEN
If refactoring breaks tests → ROLLBACK
Do not proceed with broken tests
```

**Step 2:** Analyze which test(s) failed, the failure message, what specific refactoring caused it.

**Step 3: Decide next action**
- **Option A: Skip refactoring** — Too risky; defer improvement to later
- **Option B: Smaller refactoring** — Break into smaller steps; test after each micro-step; stop at first failure
- **Option C: Fix test (if brittle)** — Update test to test behavior, not implementation; re-apply refactoring

**Step 4:** Proceed to next behavior or complete story

### Scenario 4: Rollback to Previous State

**Valid rollback scenarios:** Refactoring broke tests, implementation made things worse, went down wrong path, need to return to known good state.

**Rollback procedure:**
1. Identify changes to undo
2. Restore previous code version (`git checkout` or undo edits)
3. Run full test suite
4. Verify all tests GREEN

After rollback: code at last known good state, ready to try different approach, user decides next step.

### Scenario 5: Inconsistent Test Results

**Possible causes:**
1. Test order dependency (shared state between tests, improper isolation)
2. Timing issues (race conditions, async operations not awaited, timeouts too short)
3. External dependencies (database state varies, network/API calls unreliable)
4. Random data in tests (non-deterministic behavior)

**Recovery Steps:**
1. Run failing test alone; run in different order; identify if order-dependent
2. Check if test cleans up after itself, sets up its own data, depends on external state
3. Add proper setup/teardown; use fixtures; mock external dependencies; ensure deterministic behavior
4. Run test multiple times; run full suite multiple times; confirm consistent pass/fail

## Diagnostic Flowchart

```
Test failed unexpectedly
    ↓
What phase?
    ↓
┌───────────┬────────────┬─────────────┐
RED         GREEN        REFACTOR
↓           ↓            ↓
Should      Should       Should
fail        pass         stay green
↓           ↓            ↓
But         But          But
passes      fails        fails
↓           ↓            ↓
Test        Impl.        ROLLBACK
invalid     incomplete   immediately
↓           ↓            ↓
Revise      Revise       Try smaller
test        impl.        or skip
```

## Prevention Strategies

**RED phase:** Always run test and verify it fails; check failure message is correct.
**GREEN phase:** Run test and verify it passes; run full suite to check regressions.
**REFACTOR phase:** Run full suite after every change; small steps, test after each; rollback immediately if any test fails.

**Golden rule:**
```
Tests should ALWAYS be green except during RED phase

RED phase: Intentionally red (one test)
GREEN phase: Return to all green
REFACTOR phase: Stay all green
Between features: All green

If not green when expected → STOP and recover
```

## Common Recovery Patterns

- **The Reset:** Confused state → rollback to last known green → clean slate, try again
- **The Minimal Fix:** Small issue, clear fix → targeted correction → tests green, proceed
- **The Skip:** Risk > reward → skip problematic change → defer, maintain green
- **The Divide and Conquer:** Large change broke something → break into smaller incremental changes → identify exactly what breaks

## Resources

See `resources/` directory for:
- `failure-diagnostic-flowchart.md` - Visual decision tree
- `recovery-procedures.md` - Step-by-step recovery for each scenario
- `test-isolation-guide.md` - Ensuring test independence

## Relationship to Other Skills

- `tdd-red-phase` - RED phase failures
- `tdd-green-phase` - GREEN phase failures
- `tdd-refactor-phase` - REFACTOR phase failures
- `test-writing-patterns` - Avoiding test-related failures

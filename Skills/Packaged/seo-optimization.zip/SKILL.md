---
name: seo-optimization
description: Provide structured SEO guidance for web projects covering technical foundations and content optimization
version: "1.0.0"
frameworkCompatibility: ">=0.60.0"
lastUpdated: "2026-03-17"
license: Complete terms in LICENSE.txt
category: web
relevantTechStack: [seo, html, meta-tags, structured-data, sitemap]
invocationMode: direct-only
copyright: "Rubrical Works (c) 2026"
---

# SEO Optimization

**Purpose:** Guide developers through implementing SEO best practices during development rather than retrofitting them after launch.
**Audience:** Developers building web-facing applications who need discoverability.
**Related Skills:** `ci-cd-pipeline-design` — for deployment automation that preserves SEO settings

## When to Use This Skill

- Setting up a new web project that needs search engine visibility
- Adding meta tags, structured data, or social sharing metadata to pages
- Auditing an existing site for SEO gaps
- Configuring sitemaps, robots.txt, or canonical URLs
- Structuring content with proper heading hierarchy and semantic HTML
- Optimizing internal linking for crawlability and user navigation

## Overview

Two core areas:
1. **Technical SEO** — Meta tags, structured data, sitemaps, robots.txt, canonical URLs, Open Graph/Twitter Cards
2. **Content Optimization** — Heading hierarchy, semantic HTML, content structure, internal linking

### What This Skill Does NOT Cover (v1)

- Keyword research methodology and intent mapping
- Core Web Vitals deep-dive (LCP, FID/INP, CLS as ranking factors)
- Framework-specific guidance (SSR/SSG, SPA meta tag management)
- Accessibility-SEO overlap

See `Docs/02-Advanced/Skill-Guide-SEO.md` for curated external references on deferred topics.

## Technical SEO Essentials

### Meta Tags

```html
<head>
  <title>Page Title — Site Name</title>
  <meta name="description" content="A concise 150-160 character summary of the page content.">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="UTF-8">
  <link rel="canonical" href="https://example.com/current-page">
</head>
```

**Rules:**
- `<title>` — 50-60 characters, unique per page, primary keyword near the front
- `meta description` — 150-160 characters, compelling summary, unique per page
- `canonical` — Always set to prevent duplicate content issues

### Structured Data (JSON-LD)

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "How to Implement SEO",
  "author": { "@type": "Person", "name": "Developer Name" },
  "datePublished": "2026-01-15",
  "description": "A guide to implementing SEO best practices."
}
</script>
```

**Common schema.org types:** `Article`, `Product`, `Organization`, `BreadcrumbList`, `FAQPage`, `HowTo`, `WebSite`, `LocalBusiness`

Validate with [Google Rich Results Test](https://search.google.com/test/rich-results) or [Schema.org Validator](https://validator.schema.org/).

### Sitemaps

```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://example.com/</loc>
    <lastmod>2026-01-15</lastmod>
    <changefreq>weekly</changefreq>
    <priority>1.0</priority>
  </url>
</urlset>
```

**Rules:**
- Place at `/sitemap.xml`
- Reference from `robots.txt`: `Sitemap: https://example.com/sitemap.xml`
- Regenerate on content changes (automate in CI/CD)
- Max 50,000 URLs per sitemap; use sitemap index for larger sites

### robots.txt

```
User-agent: *
Allow: /
Disallow: /admin/
Disallow: /api/
Disallow: /private/

Sitemap: https://example.com/sitemap.xml
```

**Rules:**
- Place at site root (`/robots.txt`)
- Never block CSS/JS files (search engines need them to render pages)
- Use `Disallow` for admin panels, API endpoints, duplicate pages
- Always include `Sitemap` directive

### Canonical URLs

```html
<link rel="canonical" href="https://example.com/page">
```

**When to use:** http/https variations, www/non-www variations, URL parameters, paginated content, syndicated content.

### Open Graph and Twitter Cards

```html
<!-- Open Graph (Facebook, LinkedIn, etc.) -->
<meta property="og:title" content="Page Title">
<meta property="og:description" content="Page description for social sharing.">
<meta property="og:image" content="https://example.com/image.jpg">
<meta property="og:url" content="https://example.com/page">
<meta property="og:type" content="article">

<!-- Twitter Cards -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Page Title">
<meta name="twitter:description" content="Page description for Twitter.">
<meta name="twitter:image" content="https://example.com/image.jpg">
```

**Rules:**
- `og:image` — Minimum 1200x630px for optimal display
- `twitter:card` — Use `summary_large_image` for articles, `summary` for profiles
- Set on every shareable page, not just the homepage

## Content Optimization Essentials

### Heading Hierarchy

```html
<h1>Main Page Title</h1>
  <h2>Major Section</h2>
    <h3>Subsection</h3>
  <h2>Another Major Section</h2>
```

**Rules:**
- Exactly one `<h1>` per page
- Never skip levels (e.g., `<h1>` directly to `<h3>`)
- Headings should read as a logical outline
- Include relevant keywords naturally

### Semantic HTML

| Element | SEO Purpose |
|---------|-------------|
| `<main>` | Identifies primary content (one per page) |
| `<article>` | Self-contained content (blog post, news article) |
| `<section>` | Thematic grouping of content |
| `<nav>` | Navigation blocks (site nav, breadcrumbs) |
| `<header>` | Introductory content for page or section |
| `<footer>` | Footer content (copyright, links) |
| `<aside>` | Tangentially related content (sidebars) |
| `<time>` | Machine-readable dates (use `datetime` attribute) |

### Content Structure

- **Front-load key information** — Put the most important content first (inverted pyramid)
- **Use lists** — Easier to scan, may appear as featured snippets
- **Short paragraphs** — 2-3 sentences per paragraph
- **Descriptive link text** — Use "read the SEO guide" not "click here"
- **Image alt text** — Describe every image for accessibility and image search

### Internal Linking

- **Hub-and-spoke model** — Create topic "hub" pages that link to related detail pages
- **Contextual links** — Link from within content where relevant
- **Descriptive anchor text** — Use keyword-rich, descriptive text
- **Reasonable depth** — Every page reachable within 3 clicks from homepage
- **Fix broken links** — Regularly audit for 404s; use redirects for moved content

**Audit checklist:**
- [ ] All important pages are linked from at least one other page
- [ ] No orphan pages (pages with zero internal links pointing to them)
- [ ] Anchor text is descriptive and relevant
- [ ] No excessive links on a single page (aim for under 100 per page)

## Quick Reference Checklist

### Technical SEO
- [ ] `<title>` tag set (50-60 chars, unique)
- [ ] `meta description` set (150-160 chars, unique)
- [ ] Canonical URL set
- [ ] Open Graph tags set (`og:title`, `og:description`, `og:image`, `og:url`)
- [ ] Twitter Card tags set
- [ ] Structured data (JSON-LD) present where applicable
- [ ] Page included in sitemap
- [ ] Not blocked by robots.txt

### Content Optimization
- [ ] Single `<h1>` per page
- [ ] Heading hierarchy follows logical order (no skipped levels)
- [ ] Semantic HTML elements used (`<main>`, `<article>`, `<nav>`, `<section>`)
- [ ] Descriptive link text (no "click here")
- [ ] Images have `alt` attributes
- [ ] Internal links to related content
- [ ] Content is front-loaded (key information first)
